import axios from "axios";
import { Router } from "express";
import { fromZodError } from "zod-validation-error";
import { Incident, alarmArraySchema } from "../schema";

const router = Router();

router.post("/", async (req, res) => {
  // Validate the payload
  const result = alarmArraySchema.safeParse(req.body);
  if (!result.success) {
    return res.status(400).json({
      message: fromZodError(result.error, {
        prefix: "Invalid payload",
      }).message,
    });
  }

  const alarm = result.data[0];

  const jsonData: Incident = {
    class: "Incident",
    comment: "Created by MonliB",
    fields: {
      caller_id: "2",
      description: alarm.errmsg,
      impact: "1",
      org_id: "1",
      origin: "monitoring",
      priority: "3",
      status: "new",
      title: `${alarm.devicename} - ${alarm.event}`,
      urgency: "1",
    },
    operation: "core/create",
    output_fields: "id",
  };

  const endpoint = "webservices/rest.php";

  // Query: version=1.3&auth_user=api&auth_pwd=12345&operation=core/create
  const query = new URLSearchParams({
    version: "1.3",
    auth_user: process.env.ITOP_USER ?? "admin",
    auth_pwd: process.env.ITOP_PASSWORD ?? "admin",
    operation: "core/create",
    json_data: JSON.stringify(jsonData),
  });

  const url = new URL(endpoint, process.env.ITOP_API_URL);
  url.search = query.toString();

  try {
    const response = await axios.post(url.toString(), null, {
      headers: {
        Cookie: "__test=c5874bdf13d067e09b743984365fc286",
      },
    });
    console.log(response.data);
    res.status(200).json({ message: "Incident created" });
  } catch {
    console.log("errore");
    res.status(500).json({ message: "Failed to create Incident" });
  }
});

export default router;
