import dotenv from "dotenv";
import express, { json } from "express";
import alarmRouter from "./routes/alarm";

dotenv.config();

const app = express();

app.use(json());

app.get("/", (req, res) => {
  res.send("Hello World!");
  console.log(process.env.ITOP_URL);
});

app.use("/alarm", alarmRouter);

app.listen(3000, () => {
  console.log("MonliB listening on port 3000!");
});
