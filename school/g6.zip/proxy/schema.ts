import * as z from "zod";

export const alarmSchema = z
  .object({
    devicename: z.string(),
    eventtime: z.string(),
    event: z.string(),
    service: z.string(),
    errno: z.number(),
    errmsg: z.string(),
  })
  .strict();

export const alarmArraySchema = z.array(alarmSchema);

export const incidentSchema = z
  .object({
    class: z.string(),
    comment: z.string(),
    fields: z.object({
      caller_id: z.string(),
      description: z.string(),
      impact: z.string(),
      org_id: z.string(),
      origin: z.string(),
      priority: z.string(),
      status: z.string(),
      title: z.string(),
      urgency: z.string(),
    }),
    operation: z.string(),
    output_fields: z.string(),
  })
  .strict();

export type Incident = z.infer<typeof incidentSchema>;
