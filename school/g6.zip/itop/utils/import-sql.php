<?php

// check if post request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('HTTP/1.0 403 Forbidden');
  exit();
}


// get authorization header
apache_request_headers();
$token = apache_request_headers()['Authorization'] ?? false;

if (!$token || $token !== "k9kNnU7BhpPAywAXnKCdAUqGhEbVN3LperUihNCWYupdtQTZKC7PHfVPfaiLDwmhefGqgCFzpch4JWZ6arfKDpjEoyyLoYcZCbny") {
  header('HTTP/1.0 401 Unauthorized');
  exit();
}

require $_SERVER['DOCUMENT_ROOT'] . '/conf/production/config-itop.php';

$db_host = $MySettings['db_host'];
$db_name = $MySettings['db_name'];
$db_user = $MySettings['db_user'];
$db_pwd = $MySettings['db_pwd'];

$sql_file = __DIR__ . '/dump.sql';

// connect to mysql
$mysqli = new mysqli($db_host, $db_user, $db_pwd);

if ($mysqli->connect_error) {
  printf("Connection failed: %s\n", $mysqli->connect_error);
  exit();
}

// drop database
$mysqli->query("DROP DATABASE IF EXISTS $db_name");

// create database
$mysqli->query("CREATE DATABASE $db_name");

// select database
$mysqli->select_db($db_name);

// import sql file
$sql = file_get_contents($sql_file);
$mysqli->multi_query($sql);

// close connection
$mysqli->close();

echo "Imported successfully!";
