-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql105.epizy.com
-- Generation Time: May 30, 2023 at 04:08 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epiz_33890593_itop`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicationsolution`
--

CREATE TABLE `applicationsolution` (
  `id` int(11) NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `redundancy` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'disabled'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attachment`
--

CREATE TABLE `attachment` (
  `id` int(11) NOT NULL,
  `expire` datetime DEFAULT NULL,
  `temp_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_id` int(11) DEFAULT 0,
  `item_org_id` int(11) DEFAULT 0,
  `contents_data` longblob DEFAULT NULL,
  `contents_mimetype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contents_filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creation_date` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `businessprocess`
--

CREATE TABLE `businessprocess` (
  `id` int(11) NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `change`
--

CREATE TABLE `change` (
  `id` int(11) NOT NULL,
  `status` enum('approved','assigned','closed','implemented','monitored','new','notapproved','plannedscheduled','rejected','validated') COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `requestor_id` int(11) DEFAULT 0,
  `creation_date` datetime DEFAULT NULL,
  `impact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `supervisor_group_id` int(11) DEFAULT 0,
  `supervisor_id` int(11) DEFAULT 0,
  `manager_group_id` int(11) DEFAULT 0,
  `manager_id` int(11) DEFAULT 0,
  `outage` enum('no','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `fallback` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT 0,
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Change'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `change_approved`
--

CREATE TABLE `change_approved` (
  `id` int(11) NOT NULL,
  `approval_date` datetime DEFAULT NULL,
  `approval_comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'ApprovedChange'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `change_emergency`
--

CREATE TABLE `change_emergency` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `change_normal`
--

CREATE TABLE `change_normal` (
  `id` int(11) NOT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `change_routine`
--

CREATE TABLE `change_routine` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `connectableci`
--

CREATE TABLE `connectableci` (
  `id` int(11) NOT NULL,
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'ConnectableCI'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `connectableci`
--

INSERT INTO `connectableci` (`id`, `finalclass`) VALUES
(1, 'NetworkDevice');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `org_id` int(11) DEFAULT 0,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `notify` enum('no','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'yes',
  `function` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Contact',
  `obsolescence_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `status`, `org_id`, `email`, `phone`, `notify`, `function`, `finalclass`, `obsolescence_date`) VALUES
(1, 'My last name', 'active', 1, 'my.email@foo.org', '', 'yes', '', 'Person', NULL),
(2, 'B', 'active', 2, '', '', 'no', '', 'Person', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contacttype`
--

CREATE TABLE `contacttype` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contract`
--

CREATE TABLE `contract` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cost_currency` enum('dollars','euros') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contracttype_id` int(11) DEFAULT 0,
  `billing_frequency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cost_unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `provider_id` int(11) DEFAULT 0,
  `status` enum('implementation','obsolete','production') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Contract'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contracttype`
--

CREATE TABLE `contracttype` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customercontract`
--

CREATE TABLE `customercontract` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `databaseschema`
--

CREATE TABLE `databaseschema` (
  `id` int(11) NOT NULL,
  `dbserver_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `datacenterdevice`
--

CREATE TABLE `datacenterdevice` (
  `id` int(11) NOT NULL,
  `rack_id` int(11) DEFAULT 0,
  `enclosure_id` int(11) DEFAULT 0,
  `nb_u` int(11) DEFAULT NULL,
  `managementip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `powera_id` int(11) DEFAULT 0,
  `powerB_id` int(11) DEFAULT 0,
  `redundancy` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'DatacenterDevice'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `datacenterdevice`
--

INSERT INTO `datacenterdevice` (`id`, `rack_id`, `enclosure_id`, `nb_u`, `managementip`, `powera_id`, `powerB_id`, `redundancy`, `finalclass`) VALUES
(1, 0, 0, NULL, '', 0, 0, '1', 'NetworkDevice');

-- --------------------------------------------------------

--
-- Table structure for table `dbserver`
--

CREATE TABLE `dbserver` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deliverymodel`
--

CREATE TABLE `deliverymodel` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `deliverymodel`
--

INSERT INTO `deliverymodel` (`id`, `name`, `org_id`, `description`) VALUES
(1, 'Installations Doku', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `document`
--

CREATE TABLE `document` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT 0,
  `documenttype_id` int(11) DEFAULT 0,
  `version` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','obsolete','published') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Document',
  `obsolescence_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `documentfile`
--

CREATE TABLE `documentfile` (
  `id` int(11) NOT NULL,
  `file_data` longblob DEFAULT NULL,
  `file_mimetype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `documentnote`
--

CREATE TABLE `documentnote` (
  `id` int(11) NOT NULL,
  `text` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `documenttype`
--

CREATE TABLE `documenttype` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `documentweb`
--

CREATE TABLE `documentweb` (
  `id` int(11) NOT NULL,
  `url` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `enclosure`
--

CREATE TABLE `enclosure` (
  `id` int(11) NOT NULL,
  `rack_id` int(11) DEFAULT 0,
  `nb_u` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `summary` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` int(11) DEFAULT 0,
  `error_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `key_words` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `domains` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqcategory`
--

CREATE TABLE `faqcategory` (
  `id` int(11) NOT NULL,
  `nam` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `farm`
--

CREATE TABLE `farm` (
  `id` int(11) NOT NULL,
  `redundancy` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fiberchannelinterface`
--

CREATE TABLE `fiberchannelinterface` (
  `id` int(11) NOT NULL,
  `speed` decimal(6,2) DEFAULT NULL,
  `topology` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `wwn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `datacenterdevice_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `functionalci`
--

CREATE TABLE `functionalci` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `org_id` int(11) DEFAULT 0,
  `business_criticity` enum('high','low','medium') COLLATE utf8mb4_unicode_ci DEFAULT 'low',
  `move2production` date DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'FunctionalCI',
  `obsolescence_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `functionalci`
--

INSERT INTO `functionalci` (`id`, `name`, `description`, `org_id`, `business_criticity`, `move2production`, `finalclass`, `obsolescence_date`) VALUES
(1, 'asdf', '', 1, 'low', NULL, 'NetworkDevice', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE `group` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('implementation','obsolete','production') COLLATE utf8mb4_unicode_ci DEFAULT 'implementation',
  `org_id` int(11) DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `parent_id` int(11) DEFAULT 0,
  `parent_id_left` int(11) DEFAULT 0,
  `parent_id_right` int(11) DEFAULT 0,
  `obsolescence_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hypervisor`
--

CREATE TABLE `hypervisor` (
  `id` int(11) NOT NULL,
  `farm_id` int(11) DEFAULT 0,
  `server_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inline_image`
--

CREATE TABLE `inline_image` (
  `id` int(11) NOT NULL,
  `expire` datetime DEFAULT NULL,
  `temp_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_id` int(11) DEFAULT 0,
  `item_org_id` int(11) DEFAULT 0,
  `contents_data` longblob DEFAULT NULL,
  `contents_mimetype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contents_filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `iosversion`
--

CREATE TABLE `iosversion` (
  `id` int(11) NOT NULL,
  `brand_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ipinterface`
--

CREATE TABLE `ipinterface` (
  `id` int(11) NOT NULL,
  `ipaddress` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `macaddress` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ipgateway` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipmask` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `speed` decimal(12,2) DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'IPInterface'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ipphone`
--

CREATE TABLE `ipphone` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `key_value_store`
--

CREATE TABLE `key_value_store` (
  `id` int(11) NOT NULL,
  `namespace` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `key_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `key_value_store`
--

INSERT INTO `key_value_store` (`id`, `namespace`, `key_name`, `value`) VALUES
(1, 'ItopCounter', 'Ticket', '10');

-- --------------------------------------------------------

--
-- Table structure for table `knownerror`
--

CREATE TABLE `knownerror` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cust_id` int(11) DEFAULT 0,
  `problem_id` int(11) DEFAULT 0,
  `symptom` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rootcause` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workaround` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `solution` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `domain` enum('Application','Desktop','Network','Server') COLLATE utf8mb4_unicode_ci DEFAULT 'Application',
  `vendor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `model` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `licence`
--

CREATE TABLE `licence` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT 0,
  `usage_limit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `licence_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `perpetual` enum('no','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Licence',
  `obsolescence_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkapplicationsolutiontobusinessprocess`
--

CREATE TABLE `lnkapplicationsolutiontobusinessprocess` (
  `id` int(11) NOT NULL,
  `businessprocess_id` int(11) DEFAULT 0,
  `applicationsolution_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkapplicationsolutiontofunctionalci`
--

CREATE TABLE `lnkapplicationsolutiontofunctionalci` (
  `id` int(11) NOT NULL,
  `applicationsolution_id` int(11) DEFAULT 0,
  `functionalci_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkconnectablecitonetworkdevice`
--

CREATE TABLE `lnkconnectablecitonetworkdevice` (
  `id` int(11) NOT NULL,
  `networkdevice_id` int(11) DEFAULT 0,
  `connectableci_id` int(11) DEFAULT 0,
  `network_port` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `device_port` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` enum('downlink','uplink') COLLATE utf8mb4_unicode_ci DEFAULT 'downlink'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkcontacttocontract`
--

CREATE TABLE `lnkcontacttocontract` (
  `id` int(11) NOT NULL,
  `contract_id` int(11) DEFAULT 0,
  `contact_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkcontacttofunctionalci`
--

CREATE TABLE `lnkcontacttofunctionalci` (
  `id` int(11) NOT NULL,
  `functionalci_id` int(11) DEFAULT 0,
  `contact_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkcontacttoservice`
--

CREATE TABLE `lnkcontacttoservice` (
  `id` int(11) NOT NULL,
  `service_id` int(11) DEFAULT 0,
  `contact_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkcontacttoticket`
--

CREATE TABLE `lnkcontacttoticket` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) DEFAULT 0,
  `contact_id` int(11) DEFAULT 0,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `impact_code` enum('computed','do_not_notify','manual') COLLATE utf8mb4_unicode_ci DEFAULT 'manual'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkcontracttodocument`
--

CREATE TABLE `lnkcontracttodocument` (
  `id` int(11) NOT NULL,
  `contract_id` int(11) DEFAULT 0,
  `document_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkcustomercontracttoservice`
--

CREATE TABLE `lnkcustomercontracttoservice` (
  `id` int(11) NOT NULL,
  `customercontract_id` int(11) DEFAULT 0,
  `service_id` int(11) DEFAULT 0,
  `sla_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkdatacenterdevicetosan`
--

CREATE TABLE `lnkdatacenterdevicetosan` (
  `id` int(11) NOT NULL,
  `san_id` int(11) DEFAULT 0,
  `datacenterdevice_id` int(11) DEFAULT 0,
  `san_port` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `datacenterdevice_port` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkdeliverymodeltocontact`
--

CREATE TABLE `lnkdeliverymodeltocontact` (
  `id` int(11) NOT NULL,
  `deliverymodel_id` int(11) DEFAULT 0,
  `contact_id` int(11) DEFAULT 0,
  `role_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkdocumenttoerror`
--

CREATE TABLE `lnkdocumenttoerror` (
  `link_id` int(11) NOT NULL,
  `document_id` int(11) DEFAULT 0,
  `error_id` int(11) DEFAULT 0,
  `link_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkdocumenttofunctionalci`
--

CREATE TABLE `lnkdocumenttofunctionalci` (
  `id` int(11) NOT NULL,
  `functionalci_id` int(11) DEFAULT 0,
  `document_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkdocumenttolicence`
--

CREATE TABLE `lnkdocumenttolicence` (
  `id` int(11) NOT NULL,
  `licence_id` int(11) DEFAULT 0,
  `document_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkdocumenttopatch`
--

CREATE TABLE `lnkdocumenttopatch` (
  `id` int(11) NOT NULL,
  `patch_id` int(11) DEFAULT 0,
  `document_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkdocumenttoservice`
--

CREATE TABLE `lnkdocumenttoservice` (
  `id` int(11) NOT NULL,
  `service_id` int(11) DEFAULT 0,
  `document_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkdocumenttosoftware`
--

CREATE TABLE `lnkdocumenttosoftware` (
  `id` int(11) NOT NULL,
  `software_id` int(11) DEFAULT 0,
  `document_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkerrortofunctionalci`
--

CREATE TABLE `lnkerrortofunctionalci` (
  `link_id` int(11) NOT NULL,
  `functionalci_id` int(11) DEFAULT 0,
  `error_id` int(11) DEFAULT 0,
  `dummy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkfunctionalcitoospatch`
--

CREATE TABLE `lnkfunctionalcitoospatch` (
  `id` int(11) NOT NULL,
  `ospatch_id` int(11) DEFAULT 0,
  `functionalci_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkfunctionalcitoprovidercontract`
--

CREATE TABLE `lnkfunctionalcitoprovidercontract` (
  `id` int(11) NOT NULL,
  `providercontract_id` int(11) DEFAULT 0,
  `functionalci_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkfunctionalcitoservice`
--

CREATE TABLE `lnkfunctionalcitoservice` (
  `id` int(11) NOT NULL,
  `service_id` int(11) DEFAULT 0,
  `functionalci_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkfunctionalcitoticket`
--

CREATE TABLE `lnkfunctionalcitoticket` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) DEFAULT 0,
  `functionalci_id` int(11) DEFAULT 0,
  `impact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `impact_code` enum('computed','manual','not_impacted') COLLATE utf8mb4_unicode_ci DEFAULT 'manual'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkgrouptoci`
--

CREATE TABLE `lnkgrouptoci` (
  `id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT 0,
  `ci_id` int(11) DEFAULT 0,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkpersontoteam`
--

CREATE TABLE `lnkpersontoteam` (
  `id` int(11) NOT NULL,
  `team_id` int(11) DEFAULT 0,
  `person_id` int(11) DEFAULT 0,
  `role_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkphysicalinterfacetovlan`
--

CREATE TABLE `lnkphysicalinterfacetovlan` (
  `id` int(11) NOT NULL,
  `physicalinterface_id` int(11) DEFAULT 0,
  `vlan_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkprovidercontracttoservice`
--

CREATE TABLE `lnkprovidercontracttoservice` (
  `id` int(11) NOT NULL,
  `service_id` int(11) DEFAULT 0,
  `providercontract_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkservertovolume`
--

CREATE TABLE `lnkservertovolume` (
  `id` int(11) NOT NULL,
  `volume_id` int(11) DEFAULT 0,
  `server_id` int(11) DEFAULT 0,
  `size_used` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkslatoslt`
--

CREATE TABLE `lnkslatoslt` (
  `id` int(11) NOT NULL,
  `sla_id` int(11) DEFAULT 0,
  `slt_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnksoftwareinstancetosoftwarepatch`
--

CREATE TABLE `lnksoftwareinstancetosoftwarepatch` (
  `id` int(11) NOT NULL,
  `softwarepatch_id` int(11) DEFAULT 0,
  `softwareinstance_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnksubnettovlan`
--

CREATE TABLE `lnksubnettovlan` (
  `id` int(11) NOT NULL,
  `subnet_id` int(11) DEFAULT 0,
  `vlan_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lnkvirtualdevicetovolume`
--

CREATE TABLE `lnkvirtualdevicetovolume` (
  `id` int(11) NOT NULL,
  `volume_id` int(11) DEFAULT 0,
  `virtualdevice_id` int(11) DEFAULT 0,
  `size_used` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `org_id` int(11) DEFAULT 0,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `obsolescence_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `logicalinterface`
--

CREATE TABLE `logicalinterface` (
  `id` int(11) NOT NULL,
  `virtualmachine_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `logicalvolume`
--

CREATE TABLE `logicalvolume` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lun_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `raid_level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `storagesystem_id` int(11) DEFAULT 0,
  `obsolescence_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `middleware`
--

CREATE TABLE `middleware` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `middlewareinstance`
--

CREATE TABLE `middlewareinstance` (
  `id` int(11) NOT NULL,
  `middleware_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mobilephone`
--

CREATE TABLE `mobilephone` (
  `id` int(11) NOT NULL,
  `imei` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `hw_pin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model`
--

CREATE TABLE `model` (
  `id` int(11) NOT NULL,
  `brand_id` int(11) DEFAULT 0,
  `type` enum('DiskArray','Enclosure','IPPhone','MobilePhone','NAS','NetworkDevice','PC','PDU','Peripheral','Phone','PowerSource','Printer','Rack','SANSwitch','Server','StorageSystem','Tablet','TapeLibrary') COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nas`
--

CREATE TABLE `nas` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nasfilesystem`
--

CREATE TABLE `nasfilesystem` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `raid_level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `nas_id` int(11) DEFAULT 0,
  `obsolescence_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `networkdevice`
--

CREATE TABLE `networkdevice` (
  `id` int(11) NOT NULL,
  `networkdevicetype_id` int(11) DEFAULT 0,
  `iosversion_id` int(11) DEFAULT 0,
  `ram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `networkdevice`
--

INSERT INTO `networkdevice` (`id`, `networkdevicetype_id`, `iosversion_id`, `ram`) VALUES
(1, 6, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `networkdevicetype`
--

CREATE TABLE `networkdevicetype` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `networkdevicetype`
--

INSERT INTO `networkdevicetype` (`id`) VALUES
(6);

-- --------------------------------------------------------

--
-- Table structure for table `networkinterface`
--

CREATE TABLE `networkinterface` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'NetworkInterface',
  `obsolescence_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `organization`
--

CREATE TABLE `organization` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `parent_id` int(11) DEFAULT 0,
  `parent_id_left` int(11) DEFAULT 0,
  `parent_id_right` int(11) DEFAULT 0,
  `deliverymodel_id` int(11) DEFAULT 0,
  `obsolescence_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`id`, `name`, `code`, `status`, `parent_id`, `parent_id_left`, `parent_id_right`, `deliverymodel_id`, `obsolescence_date`) VALUES
(1, 'Room Node Company', 'RN', 'active', 0, 1, 10, 0, NULL),
(2, 'Infrastructure', '', 'active', 1, 2, 3, 0, NULL),
(3, 'Room Nodes', '', 'active', 1, 4, 5, 0, NULL),
(4, 'Data Node an Visualization', '', 'active', 1, 8, 9, 0, NULL),
(5, 'Service Management', '', 'active', 1, 6, 7, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `osfamily`
--

CREATE TABLE `osfamily` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oslicence`
--

CREATE TABLE `oslicence` (
  `id` int(11) NOT NULL,
  `osversion_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ospatch`
--

CREATE TABLE `ospatch` (
  `id` int(11) NOT NULL,
  `osversion_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `osversion`
--

CREATE TABLE `osversion` (
  `id` int(11) NOT NULL,
  `osfamily_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `othersoftware`
--

CREATE TABLE `othersoftware` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patch`
--

CREATE TABLE `patch` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Patch'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pc`
--

CREATE TABLE `pc` (
  `id` int(11) NOT NULL,
  `osfamily_id` int(11) DEFAULT 0,
  `osversion_id` int(11) DEFAULT 0,
  `cpu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` enum('desktop','laptop') COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pcsoftware`
--

CREATE TABLE `pcsoftware` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pdu`
--

CREATE TABLE `pdu` (
  `id` int(11) NOT NULL,
  `rack_id` int(11) DEFAULT 0,
  `powerstart_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `peripheral`
--

CREATE TABLE `peripheral` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `id` int(11) NOT NULL,
  `picture_data` longblob DEFAULT NULL,
  `picture_mimetype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picture_filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `employee_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `mobile_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `location_id` int(11) DEFAULT 0,
  `manager_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`id`, `picture_data`, `picture_mimetype`, `picture_filename`, `first_name`, `employee_number`, `mobile_phone`, `location_id`, `manager_id`) VALUES
(1, '', '', '', 'My first name', '', '', 0, 0),
(2, '', '', '', 'Monli', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `phone`
--

CREATE TABLE `phone` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `physicaldevice`
--

CREATE TABLE `physicaldevice` (
  `id` int(11) NOT NULL,
  `serialnumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `location_id` int(11) DEFAULT 0,
  `status` enum('implementation','obsolete','production','stock') COLLATE utf8mb4_unicode_ci DEFAULT 'production',
  `brand_id` int(11) DEFAULT 0,
  `model_id` int(11) DEFAULT 0,
  `asset_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `purchase_date` date DEFAULT NULL,
  `end_of_warranty` date DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'PhysicalDevice'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `physicaldevice`
--

INSERT INTO `physicaldevice` (`id`, `serialnumber`, `location_id`, `status`, `brand_id`, `model_id`, `asset_number`, `purchase_date`, `end_of_warranty`, `finalclass`) VALUES
(1, '', 0, 'production', 0, 0, '', NULL, NULL, 'NetworkDevice');

-- --------------------------------------------------------

--
-- Table structure for table `physicalinterface`
--

CREATE TABLE `physicalinterface` (
  `id` int(11) NOT NULL,
  `connectableci_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `powerconnection`
--

CREATE TABLE `powerconnection` (
  `id` int(11) NOT NULL,
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'PowerConnection'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `powersource`
--

CREATE TABLE `powersource` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `printer`
--

CREATE TABLE `printer` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_action`
--

CREATE TABLE `priv_action` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('test','enabled','disabled') COLLATE utf8mb4_unicode_ci DEFAULT 'test',
  `realclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Action'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_action`
--

INSERT INTO `priv_action` (`id`, `name`, `description`, `status`, `realclass`) VALUES
(1, 'Email mentioned person', '', 'enabled', 'ActionEmail');

-- --------------------------------------------------------

--
-- Table structure for table `priv_action_email`
--

CREATE TABLE `priv_action_email` (
  `id` int(11) NOT NULL,
  `test_recipient` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `from` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `from_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reply_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reply_to_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `to` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cc` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bcc` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `importance` enum('high','low','normal') COLLATE utf8mb4_unicode_ci DEFAULT 'normal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_action_email`
--

INSERT INTO `priv_action_email` (`id`, `test_recipient`, `from`, `from_label`, `reply_to`, `reply_to_label`, `to`, `cc`, `bcc`, `subject`, `body`, `importance`) VALUES
(1, '', '$current_contact->email$', '', '', '', 'SELECT Person WHERE id = :mentioned->id', NULL, NULL, 'You have been mentioned in \"$this->friendlyname$\"', '<p>Hello $mentioned-&gt;first_name$,</p>\n								<p>You have been mentioned by $current_contact-&gt;friendlyname$ in $this-&gt;hyperlink()$</p>', 'normal');

-- --------------------------------------------------------

--
-- Table structure for table `priv_action_googlechat_notif`
--

CREATE TABLE `priv_action_googlechat_notif` (
  `id` int(11) NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_action_itop_webhook`
--

CREATE TABLE `priv_action_itop_webhook` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_action_microsoftteams_notif`
--

CREATE TABLE `priv_action_microsoftteams_notif` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `message` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `image_url` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `include_list_attributes` enum('list','msteams') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `include_modify_button` enum('no','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_delete_button` enum('no','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_other_actions_button` enum('no','specify','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `specified_other_actions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_action_notification`
--

CREATE TABLE `priv_action_notification` (
  `id` int(11) NOT NULL,
  `realclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'ActionNotification'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_action_notification`
--

INSERT INTO `priv_action_notification` (`id`, `realclass`) VALUES
(1, 'ActionEmail');

-- --------------------------------------------------------

--
-- Table structure for table `priv_action_rocketchat_notif`
--

CREATE TABLE `priv_action_rocketchat_notif` (
  `id` int(11) NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bot_alias` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `bot_url_avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `bot_emoji_avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_action_slack_notif`
--

CREATE TABLE `priv_action_slack_notif` (
  `id` int(11) NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `include_list_attributes` enum('list','slack') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `include_user_info` enum('no','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_modify_button` enum('no','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_delete_button` enum('no','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_other_actions_button` enum('no','specify','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `specified_other_actions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_action_webhook`
--

CREATE TABLE `priv_action_webhook` (
  `id` int(11) NOT NULL,
  `language` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'EN US',
  `remoteapplicationconnection_id` int(11) DEFAULT 0,
  `test_remoteapplicationconnection_id` int(11) DEFAULT 0,
  `method` enum('delete','get','patch','post','put') COLLATE utf8mb4_unicode_ci DEFAULT 'post',
  `headers` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prepare_payload_callback` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `process_response_callback` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `realclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'ActionWebhook'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_app_dashboards`
--

CREATE TABLE `priv_app_dashboards` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT 0,
  `menu_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `contents` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_app_preferences`
--

CREATE TABLE `priv_app_preferences` (
  `id` int(11) NOT NULL,
  `userid` int(11) DEFAULT 0,
  `preferences` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_app_preferences`
--

INSERT INTO `priv_app_preferences` (`id`, `userid`, `preferences`) VALUES
(1, 1, 'a:4:{s:13:\"welcome_popup\";s:1:\"0\";s:24:\"navigation_menu.expanded\";s:8:\"expanded\";s:20:\"quick_create_history\";a:6:{i:0;a:1:{s:5:\"class\";s:6:\"Person\";}i:1;a:1:{s:5:\"class\";s:12:\"Organization\";}i:2;a:1:{s:5:\"class\";s:7:\"Service\";}i:3;a:1:{s:5:\"class\";s:9:\"UserLocal\";}i:4;a:1:{s:5:\"class\";s:8:\"Incident\";}i:5;a:1:{s:5:\"class\";s:13:\"NetworkDevice\";}}s:19:\"itophub_auto_submit\";s:1:\"1\";}'),
(2, 2, 'a:2:{s:13:\"welcome_popup\";s:1:\"1\";s:24:\"navigation_menu.expanded\";s:8:\"expanded\";}');

-- --------------------------------------------------------

--
-- Table structure for table `priv_async_send_email`
--

CREATE TABLE `priv_async_send_email` (
  `id` int(11) NOT NULL,
  `version` int(11) DEFAULT 1,
  `to` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_async_send_web_request`
--

CREATE TABLE `priv_async_send_web_request` (
  `id` int(11) NOT NULL,
  `request` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_async_task`
--

CREATE TABLE `priv_async_task` (
  `id` int(11) NOT NULL,
  `status` enum('error','idle','planned','running') COLLATE utf8mb4_unicode_ci DEFAULT 'planned',
  `created` datetime DEFAULT NULL,
  `started` datetime DEFAULT NULL,
  `planned` datetime DEFAULT NULL,
  `event_id` int(11) DEFAULT 0,
  `remaining_retries` int(11) DEFAULT 0,
  `last_error_code` int(11) DEFAULT 0,
  `last_error` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_attempt` datetime DEFAULT NULL,
  `realclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'AsyncTask'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_auditcategory`
--

CREATE TABLE `priv_auditcategory` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `definition_set` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_auditrule`
--

CREATE TABLE `priv_auditrule` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `query` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valid_flag` enum('false','true') COLLATE utf8mb4_unicode_ci DEFAULT 'true',
  `category_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_backgroundtask`
--

CREATE TABLE `priv_backgroundtask` (
  `id` int(11) NOT NULL,
  `class_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `first_run_date` datetime DEFAULT NULL,
  `latest_run_date` datetime DEFAULT NULL,
  `next_run_date` datetime DEFAULT NULL,
  `total_exec_count` int(11) DEFAULT 0,
  `latest_run_duration` decimal(8,3) DEFAULT 0.000,
  `min_run_duration` decimal(8,3) DEFAULT 0.000,
  `max_run_duration` decimal(8,3) DEFAULT 0.000,
  `average_run_duration` decimal(8,3) DEFAULT 0.000,
  `running` tinyint(1) DEFAULT 0,
  `status` enum('active','paused','removed') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `system_user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_bulk_export_result`
--

CREATE TABLE `priv_bulk_export_result` (
  `id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT 0,
  `chunk_size` int(11) DEFAULT 0,
  `format` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `temp_file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `search` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_info` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `localize_output` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_change`
--

CREATE TABLE `priv_change` (
  `id` int(11) NOT NULL,
  `date` datetime DEFAULT NULL,
  `userinfo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `user_id` int(11) DEFAULT 0,
  `origin` enum('csv-import.php','csv-interactive','custom-extension','email-processing','interactive','synchro-data-source','webservice-rest','webservice-soap') COLLATE utf8mb4_unicode_ci DEFAULT 'interactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_change`
--

INSERT INTO `priv_change` (`id`, `date`, `userinfo`, `user_id`, `origin`) VALUES
(1, '2023-03-28 11:35:19', '', 0, 'interactive'),
(2, '2023-03-28 11:35:22', 'Initialization', 0, 'interactive'),
(3, '2023-03-28 11:35:23', '', 0, 'interactive'),
(4, '2023-04-04 09:15:49', 'My first name My last name', 1, 'interactive'),
(5, '2023-04-04 09:15:54', 'My first name My last name', 1, 'interactive'),
(6, '2023-04-04 10:01:22', 'My first name My last name', 1, 'interactive'),
(7, '2023-04-04 10:27:22', 'My first name My last name', 1, 'interactive'),
(8, '2023-04-04 11:03:18', 'My first name My last name', 1, 'interactive'),
(9, '2023-04-18 08:58:49', 'My first name My last name', 1, 'interactive'),
(10, '2023-04-18 10:00:25', 'My first name My last name', 1, 'interactive'),
(11, '2023-04-18 10:00:28', 'My first name My last name', 1, 'interactive'),
(12, '2023-04-18 10:25:36', 'My first name My last name', 1, 'interactive'),
(13, '2023-04-18 10:26:06', 'My first name My last name', 1, 'interactive'),
(14, '2023-04-18 10:48:27', 'My first name My last name', 1, 'interactive'),
(15, '2023-04-18 10:48:51', 'My first name My last name', 1, 'interactive'),
(16, '2023-04-18 10:49:21', 'My first name My last name', 1, 'interactive'),
(17, '2023-04-18 10:50:10', 'My first name My last name', 1, 'interactive'),
(18, '2023-04-18 10:50:42', 'My first name My last name', 1, 'interactive'),
(19, '2023-05-23 09:20:37', 'Creating new Incident! :)', 1, 'webservice-rest'),
(20, '2023-05-23 09:24:31', 'Creating new Incident! :)', 1, 'webservice-rest'),
(21, '2023-05-23 09:29:00', 'My first name My last name', 1, 'interactive'),
(22, '2023-05-23 09:40:54', 'My first name My last name', 1, 'interactive'),
(23, '2023-05-23 09:42:01', 'My first name My last name', 1, 'interactive'),
(24, '2023-05-23 09:43:26', 'My first name My last name', 1, 'interactive'),
(25, '2023-05-23 09:44:56', 'Creating new Incident! :)', 1, 'webservice-rest'),
(26, '2023-05-23 09:45:44', 'Creating new Incident! :)', 1, 'webservice-rest'),
(27, '2023-05-23 09:46:05', 'My first name My last name', 1, 'interactive'),
(28, '2023-05-23 09:46:30', 'My first name My last name', 1, 'interactive'),
(29, '2023-05-23 09:47:51', 'My first name My last name', 1, 'interactive'),
(30, '2023-05-23 09:48:23', 'My first name My last name', 1, 'interactive'),
(31, '2023-05-23 10:02:05', 'Creating new Incident! :)', 1, 'webservice-rest'),
(32, '2023-05-23 10:33:38', 'Created by MonliB', 1, 'webservice-rest'),
(33, '2023-05-23 10:34:51', 'Created by MonliB', 1, 'webservice-rest'),
(34, '2023-05-23 11:19:52', 'Created by MonliB', 1, 'webservice-rest');

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop`
--

CREATE TABLE `priv_changeop` (
  `id` int(11) NOT NULL,
  `changeid` int(11) DEFAULT 0,
  `objclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `objkey` int(11) DEFAULT 0,
  `optype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'CMDBChangeOp'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_changeop`
--

INSERT INTO `priv_changeop` (`id`, `changeid`, `objclass`, `objkey`, `optype`) VALUES
(1, 1, 'TriggerOnObjectMention', 1, 'CMDBChangeOpCreate'),
(2, 1, 'TriggerOnObjectMention', 2, 'CMDBChangeOpCreate'),
(4, 1, 'TriggerOnObjectMention', 1, 'CMDBChangeOpSetAttributeLinksAddRemove'),
(5, 1, 'lnkTriggerAction', 1, 'CMDBChangeOpCreate'),
(7, 1, 'TriggerOnObjectMention', 2, 'CMDBChangeOpSetAttributeLinksAddRemove'),
(8, 1, 'lnkTriggerAction', 2, 'CMDBChangeOpCreate'),
(9, 1, 'ActionEmail', 1, 'CMDBChangeOpCreate'),
(10, 1, 'QueryOQL', 1, 'CMDBChangeOpCreate'),
(11, 1, 'QueryOQL', 2, 'CMDBChangeOpCreate'),
(12, 1, 'QueryOQL', 3, 'CMDBChangeOpCreate'),
(13, 1, 'QueryOQL', 4, 'CMDBChangeOpCreate'),
(14, 1, 'QueryOQL', 5, 'CMDBChangeOpCreate'),
(15, 1, 'QueryOQL', 6, 'CMDBChangeOpCreate'),
(16, 1, 'QueryOQL', 7, 'CMDBChangeOpCreate'),
(17, 1, 'QueryOQL', 8, 'CMDBChangeOpCreate'),
(18, 1, 'QueryOQL', 9, 'CMDBChangeOpCreate'),
(19, 1, 'QueryOQL', 10, 'CMDBChangeOpCreate'),
(20, 1, 'QueryOQL', 11, 'CMDBChangeOpCreate'),
(21, 1, 'QueryOQL', 12, 'CMDBChangeOpCreate'),
(22, 1, 'QueryOQL', 13, 'CMDBChangeOpCreate'),
(23, 1, 'URP_Profiles', 1, 'CMDBChangeOpCreate'),
(24, 1, 'URP_Profiles', 1024, 'CMDBChangeOpCreate'),
(25, 1, 'URP_Profiles', 3, 'CMDBChangeOpCreate'),
(26, 1, 'URP_Profiles', 4, 'CMDBChangeOpCreate'),
(27, 1, 'URP_Profiles', 5, 'CMDBChangeOpCreate'),
(28, 1, 'URP_Profiles', 6, 'CMDBChangeOpCreate'),
(29, 1, 'URP_Profiles', 7, 'CMDBChangeOpCreate'),
(30, 1, 'URP_Profiles', 8, 'CMDBChangeOpCreate'),
(31, 1, 'URP_Profiles', 9, 'CMDBChangeOpCreate'),
(32, 1, 'URP_Profiles', 10, 'CMDBChangeOpCreate'),
(33, 1, 'URP_Profiles', 11, 'CMDBChangeOpCreate'),
(34, 1, 'URP_Profiles', 2, 'CMDBChangeOpCreate'),
(35, 1, 'URP_Profiles', 12, 'CMDBChangeOpCreate'),
(36, 1, 'Organization', 1, 'CMDBChangeOpCreate'),
(37, 1, 'Person', 1, 'CMDBChangeOpCreate'),
(39, 1, 'URP_Profiles', 1, 'CMDBChangeOpSetAttributeLinksAddRemove'),
(40, 1, 'URP_UserProfile', 1, 'CMDBChangeOpCreate'),
(41, 1, 'UserLocal', 1, 'CMDBChangeOpCreate'),
(42, 2, 'RemoteApplicationType', 1, 'CMDBChangeOpCreate'),
(43, 2, 'RemoteApplicationType', 2, 'CMDBChangeOpCreate'),
(44, 2, 'RemoteApplicationType', 3, 'CMDBChangeOpCreate'),
(45, 2, 'RemoteApplicationType', 4, 'CMDBChangeOpCreate'),
(46, 2, 'RemoteApplicationType', 5, 'CMDBChangeOpCreate'),
(47, 3, 'ModuleInstallation', 1, 'CMDBChangeOpCreate'),
(48, 3, 'ModuleInstallation', 2, 'CMDBChangeOpCreate'),
(49, 3, 'ModuleInstallation', 3, 'CMDBChangeOpCreate'),
(50, 3, 'ModuleInstallation', 4, 'CMDBChangeOpCreate'),
(51, 3, 'ModuleInstallation', 5, 'CMDBChangeOpCreate'),
(52, 3, 'ModuleInstallation', 6, 'CMDBChangeOpCreate'),
(53, 3, 'ModuleInstallation', 7, 'CMDBChangeOpCreate'),
(54, 3, 'ModuleInstallation', 8, 'CMDBChangeOpCreate'),
(55, 3, 'ModuleInstallation', 9, 'CMDBChangeOpCreate'),
(56, 3, 'ModuleInstallation', 10, 'CMDBChangeOpCreate'),
(57, 3, 'ModuleInstallation', 11, 'CMDBChangeOpCreate'),
(58, 3, 'ModuleInstallation', 12, 'CMDBChangeOpCreate'),
(59, 3, 'ModuleInstallation', 13, 'CMDBChangeOpCreate'),
(60, 3, 'ModuleInstallation', 14, 'CMDBChangeOpCreate'),
(61, 3, 'ModuleInstallation', 15, 'CMDBChangeOpCreate'),
(62, 3, 'ModuleInstallation', 16, 'CMDBChangeOpCreate'),
(63, 3, 'ModuleInstallation', 17, 'CMDBChangeOpCreate'),
(64, 3, 'ModuleInstallation', 18, 'CMDBChangeOpCreate'),
(65, 3, 'ModuleInstallation', 19, 'CMDBChangeOpCreate'),
(66, 3, 'ModuleInstallation', 20, 'CMDBChangeOpCreate'),
(67, 3, 'ModuleInstallation', 21, 'CMDBChangeOpCreate'),
(68, 3, 'ModuleInstallation', 22, 'CMDBChangeOpCreate'),
(69, 3, 'ModuleInstallation', 23, 'CMDBChangeOpCreate'),
(70, 3, 'ModuleInstallation', 24, 'CMDBChangeOpCreate'),
(71, 3, 'ModuleInstallation', 25, 'CMDBChangeOpCreate'),
(72, 3, 'ModuleInstallation', 26, 'CMDBChangeOpCreate'),
(73, 3, 'ModuleInstallation', 27, 'CMDBChangeOpCreate'),
(74, 3, 'ModuleInstallation', 28, 'CMDBChangeOpCreate'),
(75, 3, 'ModuleInstallation', 29, 'CMDBChangeOpCreate'),
(76, 3, 'ModuleInstallation', 30, 'CMDBChangeOpCreate'),
(77, 3, 'ModuleInstallation', 31, 'CMDBChangeOpCreate'),
(78, 3, 'ModuleInstallation', 32, 'CMDBChangeOpCreate'),
(79, 3, 'ModuleInstallation', 33, 'CMDBChangeOpCreate'),
(80, 3, 'ModuleInstallation', 34, 'CMDBChangeOpCreate'),
(81, 3, 'ModuleInstallation', 35, 'CMDBChangeOpCreate'),
(82, 3, 'ModuleInstallation', 36, 'CMDBChangeOpCreate'),
(83, 3, 'ModuleInstallation', 37, 'CMDBChangeOpCreate'),
(84, 3, 'ModuleInstallation', 38, 'CMDBChangeOpCreate'),
(85, 3, 'ExtensionInstallation', 1, 'CMDBChangeOpCreate'),
(86, 3, 'ExtensionInstallation', 2, 'CMDBChangeOpCreate'),
(87, 3, 'ExtensionInstallation', 3, 'CMDBChangeOpCreate'),
(88, 3, 'ExtensionInstallation', 4, 'CMDBChangeOpCreate'),
(89, 3, 'ExtensionInstallation', 5, 'CMDBChangeOpCreate'),
(90, 3, 'ExtensionInstallation', 6, 'CMDBChangeOpCreate'),
(91, 3, 'ExtensionInstallation', 7, 'CMDBChangeOpCreate'),
(92, 3, 'ExtensionInstallation', 8, 'CMDBChangeOpCreate'),
(93, 3, 'ExtensionInstallation', 9, 'CMDBChangeOpCreate'),
(94, 3, 'ExtensionInstallation', 10, 'CMDBChangeOpCreate'),
(95, 3, 'ExtensionInstallation', 11, 'CMDBChangeOpCreate'),
(96, 3, 'ExtensionInstallation', 12, 'CMDBChangeOpCreate'),
(97, 3, 'ExtensionInstallation', 13, 'CMDBChangeOpCreate'),
(98, 4, 'NetworkDeviceType', 6, 'CMDBChangeOpCreate'),
(99, 5, 'NetworkDevice', 1, 'CMDBChangeOpCreate'),
(100, 6, 'Incident', 1, 'CMDBChangeOpCreate'),
(101, 7, 'UserLocal', 1, 'CMDBChangeOpSetAttributeLinksAddRemove'),
(102, 7, 'URP_Profiles', 1024, 'CMDBChangeOpSetAttributeLinksAddRemove'),
(103, 7, 'URP_UserProfile', 2, 'CMDBChangeOpCreate'),
(105, 8, 'URP_Profiles', 1024, 'CMDBChangeOpSetAttributeLinksAddRemove'),
(106, 8, 'URP_UserProfile', 3, 'CMDBChangeOpCreate'),
(107, 8, 'UserLocal', 2, 'CMDBChangeOpCreate'),
(108, 9, 'Service', 1, 'CMDBChangeOpCreate'),
(109, 10, 'DeliveryModel', 1, 'CMDBChangeOpCreate'),
(110, 11, 'Organization', 2, 'CMDBChangeOpCreate'),
(111, 12, 'Organization', 1, 'CMDBChangeOpSetAttributeScalar'),
(112, 12, 'Organization', 1, 'CMDBChangeOpSetAttributeScalar'),
(113, 13, 'Organization', 1, 'CMDBChangeOpSetAttributeScalar'),
(114, 14, 'Organization', 2, 'CMDBChangeOpSetAttributeScalar'),
(115, 14, 'Organization', 2, 'CMDBChangeOpSetAttributeScalar'),
(116, 14, 'Organization', 2, 'CMDBChangeOpSetAttributeScalar'),
(117, 15, 'Organization', 3, 'CMDBChangeOpCreate'),
(118, 16, 'Organization', 4, 'CMDBChangeOpCreate'),
(119, 17, 'Organization', 5, 'CMDBChangeOpCreate'),
(120, 18, 'Organization', 4, 'CMDBChangeOpSetAttributeScalar'),
(123, 21, 'Ticket', 2, 'CMDBChangeOpDelete'),
(124, 22, 'Person', 2, 'CMDBChangeOpCreate'),
(125, 23, 'Person', 2, 'CMDBChangeOpSetAttributeScalar'),
(126, 24, 'UserLocal', 2, 'CMDBChangeOpSetAttributeScalar'),
(128, 26, 'Incident', 5, 'CMDBChangeOpCreate'),
(129, 27, 'Ticket', 4, 'CMDBChangeOpDelete'),
(130, 28, 'Ticket', 3, 'CMDBChangeOpDelete'),
(131, 29, 'Person', 2, 'CMDBChangeOpSetAttributeScalar'),
(132, 29, 'Person', 2, 'CMDBChangeOpSetAttributeScalar'),
(133, 30, 'Person', 2, 'CMDBChangeOpSetAttributeScalar'),
(134, 30, 'Person', 2, 'CMDBChangeOpSetAttributeScalar'),
(135, 31, 'Incident', 6, 'CMDBChangeOpCreate'),
(136, 32, 'Incident', 7, 'CMDBChangeOpCreate'),
(137, 33, 'Incident', 8, 'CMDBChangeOpCreate'),
(138, 34, 'Incident', 9, 'CMDBChangeOpCreate');

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_attachment_added`
--

CREATE TABLE `priv_changeop_attachment_added` (
  `id` int(11) NOT NULL,
  `attachment_id` int(11) DEFAULT 0,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_attachment_removed`
--

CREATE TABLE `priv_changeop_attachment_removed` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_create`
--

CREATE TABLE `priv_changeop_create` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_changeop_create`
--

INSERT INTO `priv_changeop_create` (`id`) VALUES
(1),
(2),
(5),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18),
(19),
(20),
(21),
(22),
(23),
(24),
(25),
(26),
(27),
(28),
(29),
(30),
(31),
(32),
(33),
(34),
(35),
(36),
(37),
(40),
(41),
(42),
(43),
(44),
(45),
(46),
(47),
(48),
(49),
(50),
(51),
(52),
(53),
(54),
(55),
(56),
(57),
(58),
(59),
(60),
(61),
(62),
(63),
(64),
(65),
(66),
(67),
(68),
(69),
(70),
(71),
(72),
(73),
(74),
(75),
(76),
(77),
(78),
(79),
(80),
(81),
(82),
(83),
(84),
(85),
(86),
(87),
(88),
(89),
(90),
(91),
(92),
(93),
(94),
(95),
(96),
(97),
(98),
(99),
(100),
(103),
(106),
(107),
(108),
(109),
(110),
(117),
(118),
(119),
(124),
(128),
(135),
(136),
(137),
(138);

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_delete`
--

CREATE TABLE `priv_changeop_delete` (
  `id` int(11) NOT NULL,
  `fclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `fname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_changeop_delete`
--

INSERT INTO `priv_changeop_delete` (`id`, `fclass`, `fname`) VALUES
(123, 'Incident', 'I-000003'),
(129, 'Incident', 'I-000005'),
(130, 'Incident', 'I-000004');

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_links`
--

CREATE TABLE `priv_changeop_links` (
  `id` int(11) NOT NULL,
  `item_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_id` int(11) DEFAULT 0,
  `optype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'CMDBChangeOpSetAttributeLinks'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_changeop_links`
--

INSERT INTO `priv_changeop_links` (`id`, `item_class`, `item_id`, `optype`) VALUES
(4, 'Action', 1, 'CMDBChangeOpSetAttributeLinksAddRemove'),
(7, 'Action', 1, 'CMDBChangeOpSetAttributeLinksAddRemove'),
(39, 'User', 1, 'CMDBChangeOpSetAttributeLinksAddRemove'),
(101, 'URP_Profiles', 1024, 'CMDBChangeOpSetAttributeLinksAddRemove'),
(102, 'User', 1, 'CMDBChangeOpSetAttributeLinksAddRemove'),
(105, 'User', 2, 'CMDBChangeOpSetAttributeLinksAddRemove');

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_links_addremove`
--

CREATE TABLE `priv_changeop_links_addremove` (
  `id` int(11) NOT NULL,
  `type` enum('added','removed') COLLATE utf8mb4_unicode_ci DEFAULT 'added'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_changeop_links_addremove`
--

INSERT INTO `priv_changeop_links_addremove` (`id`, `type`) VALUES
(4, 'added'),
(7, 'added'),
(39, 'added'),
(101, 'added'),
(102, 'added'),
(105, 'added');

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_links_tune`
--

CREATE TABLE `priv_changeop_links_tune` (
  `id` int(11) NOT NULL,
  `link_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_plugin`
--

CREATE TABLE `priv_changeop_plugin` (
  `id` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_setatt`
--

CREATE TABLE `priv_changeop_setatt` (
  `id` int(11) NOT NULL,
  `attcode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `optype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'CMDBChangeOpSetAttribute'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_changeop_setatt`
--

INSERT INTO `priv_changeop_setatt` (`id`, `attcode`, `optype`) VALUES
(4, 'action_list', 'CMDBChangeOpSetAttributeLinksAddRemove'),
(7, 'action_list', 'CMDBChangeOpSetAttributeLinksAddRemove'),
(39, 'user_list', 'CMDBChangeOpSetAttributeLinksAddRemove'),
(101, 'profile_list', 'CMDBChangeOpSetAttributeLinksAddRemove'),
(102, 'user_list', 'CMDBChangeOpSetAttributeLinksAddRemove'),
(105, 'user_list', 'CMDBChangeOpSetAttributeLinksAddRemove'),
(111, 'name', 'CMDBChangeOpSetAttributeScalar'),
(112, 'code', 'CMDBChangeOpSetAttributeScalar'),
(113, 'name', 'CMDBChangeOpSetAttributeScalar'),
(114, 'name', 'CMDBChangeOpSetAttributeScalar'),
(115, 'code', 'CMDBChangeOpSetAttributeScalar'),
(116, 'deliverymodel_id', 'CMDBChangeOpSetAttributeScalar'),
(120, 'parent_id', 'CMDBChangeOpSetAttributeScalar'),
(125, 'notify', 'CMDBChangeOpSetAttributeScalar'),
(126, 'contactid', 'CMDBChangeOpSetAttributeScalar'),
(131, 'name', 'CMDBChangeOpSetAttributeScalar'),
(132, 'first_name', 'CMDBChangeOpSetAttributeScalar'),
(133, 'name', 'CMDBChangeOpSetAttributeScalar'),
(134, 'first_name', 'CMDBChangeOpSetAttributeScalar');

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_setatt_custfields`
--

CREATE TABLE `priv_changeop_setatt_custfields` (
  `id` int(11) NOT NULL,
  `prevdata` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_setatt_data`
--

CREATE TABLE `priv_changeop_setatt_data` (
  `id` int(11) NOT NULL,
  `prevdata_data` longblob DEFAULT NULL,
  `prevdata_mimetype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prevdata_filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_setatt_encrypted`
--

CREATE TABLE `priv_changeop_setatt_encrypted` (
  `id` int(11) NOT NULL,
  `data` tinyblob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_setatt_html`
--

CREATE TABLE `priv_changeop_setatt_html` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_setatt_log`
--

CREATE TABLE `priv_changeop_setatt_log` (
  `id` int(11) NOT NULL,
  `lastentry` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_setatt_longtext`
--

CREATE TABLE `priv_changeop_setatt_longtext` (
  `id` int(11) NOT NULL,
  `prevdata` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `optype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'CMDBChangeOpSetAttributeLongText'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_setatt_pwd`
--

CREATE TABLE `priv_changeop_setatt_pwd` (
  `id` int(11) NOT NULL,
  `prev_pwd_hash` tinyblob DEFAULT NULL,
  `prev_pwd_salt` tinyblob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_setatt_scalar`
--

CREATE TABLE `priv_changeop_setatt_scalar` (
  `id` int(11) NOT NULL,
  `oldvalue` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `newvalue` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_changeop_setatt_scalar`
--

INSERT INTO `priv_changeop_setatt_scalar` (`id`, `oldvalue`, `newvalue`) VALUES
(111, 'My Company/Department', 'Room Node'),
(112, 'SOMECODE', 'RN'),
(113, 'Room Node', 'Room Node Company'),
(114, 'Test Untergruppe', 'Infrastructure'),
(115, 'lol', ''),
(116, '1', '0'),
(120, '0', ''),
(125, 'yes', 'no'),
(126, '0', '2'),
(131, 'MonliB', 'Monli'),
(132, 'MonliB', 'B'),
(133, 'Monli', 'B'),
(134, 'B', 'Monli');

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_setatt_tagset`
--

CREATE TABLE `priv_changeop_setatt_tagset` (
  `id` int(11) NOT NULL,
  `oldvalue` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `newvalue` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_setatt_text`
--

CREATE TABLE `priv_changeop_setatt_text` (
  `id` int(11) NOT NULL,
  `prevdata` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_changeop_setatt_url`
--

CREATE TABLE `priv_changeop_setatt_url` (
  `id` int(11) NOT NULL,
  `oldvalue` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `newvalue` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_db_properties`
--

CREATE TABLE `priv_db_properties` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `change_date` datetime DEFAULT NULL,
  `change_comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_db_properties`
--

INSERT INTO `priv_db_properties` (`id`, `name`, `description`, `value`, `change_date`, `change_comment`) VALUES
(1, 'database_uuid', 'Unique ID of this iTop Database', '{FF5D2147-A80A-AB8C-38D4-C4801A54FDCF}', '2023-03-28 11:35:18', 'Installation/upgrade of iTop');

-- --------------------------------------------------------

--
-- Table structure for table `priv_event`
--

CREATE TABLE `priv_event` (
  `id` int(11) NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `userinfo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `realclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Event'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_event`
--

INSERT INTO `priv_event` (`id`, `message`, `date`, `userinfo`, `realclass`) VALUES
(1, 'No result for the single row query: \'SELECT\n DISTINCT `Incident`.`id` AS `Incidentid`,\n `Incident_Ticket`.`operational_status` AS `Incidentoperational_status`,\n `Incident_Ticket`.`ref` AS `Incidentref`,\n `Incident_Ticket`.`org_id` AS `Incidentorg_id`,\n `Organization_org_id`.`name` AS `Incidentorg_name`,\n `Incident_Ticket`.`caller_id` AS `Incidentcaller_id`,\n `Person_caller_id_Contact`.`name` AS `Incidentcaller_name`,\n `Incident_Ticket`.`team_id` AS `Incidentteam_id`,\n `Team_team_id_Contact`.`email` AS `Incidentteam_name`,\n `Incident_Ticket`.`agent_id` AS `Incidentagent_id`,\n `Person_agent_id_Contact`.`name` AS `Incidentagent_name`,\n `Incident_Ticket`.`title` AS `Incidenttitle`,\n `Incident_Ticket`.`description` AS `Incidentdescription`,\n `Incident_Ticket`.`start_date` AS `Incidentstart_date`,\n `Incident_Ticket`.`end_date` AS `Incidentend_date`,\n `Incident_Ticket`.`last_update` AS `Incidentlast_update`,\n `Incident_Ticket`.`close_date` AS `Incidentclose_date`,\n `Incident_Ticket`.`private_log` AS `Incidentprivate_log`,\n `Incident`.`status` AS `Incidentstatus`,\n `Incident`.`impact` AS `Incidentimpact`,\n `Incident`.`priority` AS `Incidentpriority`,\n `Incident`.`urgency` AS `Incidenturgency`,\n `Incident`.`origin` AS `Incidentorigin`,\n `Incident`.`service_id` AS `Incidentservice_id`,\n `Service_service_id`.`name` AS `Incidentservice_name`,\n `Incident`.`servicesubcategory_id` AS `Incidentservicesubcategory_id`,\n `ServiceSubcategory_servicesubcategory_id`.`name` AS `Incidentservicesubcategory_name`,\n `Incident`.`escalation_flag` AS `Incidentescalation_flag`,\n `Incident`.`escalation_reason` AS `Incidentescalation_reason`,\n `Incident`.`assignment_date` AS `Incidentassignment_date`,\n `Incident`.`resolution_date` AS `Incidentresolution_date`,\n `Incident`.`last_pending_date` AS `Incidentlast_pending_date`,\n `Incident`.`cumulatedpending_timespent` AS `Incidentcumulatedpending`,\n `Incident`.`tto_timespent` AS `Incidenttto`,\n `Incident`.`ttr_timespent` AS `Incidentttr`,\n `Incident`.`tto_100_deadline` AS `Incidenttto_escalation_deadline`,\n `Incident`.`tto_100_passed` AS `Incidentsla_tto_passed`,\n `Incident`.`tto_100_overrun` AS `Incidentsla_tto_over`,\n `Incident`.`ttr_100_deadline` AS `Incidentttr_escalation_deadline`,\n `Incident`.`ttr_100_passed` AS `Incidentsla_ttr_passed`,\n `Incident`.`ttr_100_overrun` AS `Incidentsla_ttr_over`,\n `Incident`.`time_spent` AS `Incidenttime_spent`,\n `Incident`.`resolution_code` AS `Incidentresolution_code`,\n `Incident`.`solution` AS `Incidentsolution`,\n `Incident`.`pending_reason` AS `Incidentpending_reason`,\n `Incident`.`parent_incident_id` AS `Incidentparent_incident_id`,\n `Incident_parent_incident_id_Ticket`.`ref` AS `Incidentparent_incident_ref`,\n `Incident`.`parent_problem_id` AS `Incidentparent_problem_id`,\n `Problem_parent_problem_id_Ticket`.`ref` AS `Incidentparent_problem_ref`,\n `Incident`.`parent_change_id` AS `Incidentparent_change_id`,\n `Change_parent_change_id_Ticket`.`ref` AS `Incidentparent_change_ref`,\n `Incident`.`public_log` AS `Incidentpublic_log`,\n `Incident`.`user_satisfaction` AS `Incidentuser_satisfaction`,\n `Incident`.`user_commment` AS `Incidentuser_comment`,\n `Incident_Ticket`.`finalclass` AS `Incidentfinalclass`,\n CAST(CONCAT(COALESCE(`Incident_Ticket`.`ref`, \'\')) AS CHAR) AS `Incidentfriendlyname`,\n CAST(CONCAT(COALESCE(`Organization_org_id`.`name`, \'\')) AS CHAR) AS `Incidentorg_id_friendlyname`,\n COALESCE((`Organization_org_id`.`status` = \'inactive\'), 0) AS `Incidentorg_id_obsolescence_flag`,\n CAST(CONCAT(COALESCE(`Person_caller_id`.`first_name`, \'\'), COALESCE(\' \', \'\'), COALESCE(`Person_caller_id_Contact`.`name`, \'\')) AS CHAR) AS `Incidentcaller_id_friendlyname`,\n COALESCE((`Person_caller_id_Contact`.`status` = \'inactive\'), 0) AS `Incidentcaller_id_obsolescence_flag`,\n CAST(CONCAT(COALESCE(`Team_team_id_Contact`.`name`, \'\')) AS CHAR) AS `Incidentteam_id_friendlyname`,\n COALESCE((`Team_team_id_Contact`.`status` = \'inactive\'), 0) AS `Incidentteam_id_obsolescence_flag`,\n CAST(CONCAT(COALESCE(`Person_agent_id`.`first_name`, \'\'), COALESCE(\' \', \'\'), COALESCE(`Person_agent_id_Contact`.`name`, \'\')) AS CHAR) AS `Incidentagent_id_friendlyname`,\n COALESCE((`Person_agent_id_Contact`.`status` = \'inactive\'), 0) AS `Incidentagent_id_obsolescence_flag`,\n CAST(CONCAT(COALESCE(`Service_service_id`.`name`, \'\')) AS CHAR) AS `Incidentservice_id_friendlyname`,\n CAST(CONCAT(COALESCE(`ServiceSubcategory_servicesubcategory_id`.`name`, \'\')) AS CHAR) AS `Incidentservicesubcategory_id_friendlyname`,\n CAST(CONCAT(COALESCE(`Incident_parent_incident_id_Ticket`.`ref`, \'\')) AS CHAR) AS `Incidentparent_incident_id_friendlyname`,\n CAST(CONCAT(COALESCE(`Problem_parent_problem_id_Ticket`.`ref`, \'\')) AS CHAR) AS `Incidentparent_problem_id_friendlyname`,\n CAST(CONCAT(COALESCE(`Change_parent_change_id_Ticket`.`ref`, \'\')) AS CHAR) AS `Incidentparent_change_id_friendlyname`,\n `Change_parent_change_id_Ticket`.`finalclass` AS `Incidentparent_change_id_finalclass_recall`,\n `Incident`.`cumulatedpending_started` AS `Incidentcumulatedpending_started`,\n `Incident`.`cumulatedpending_laststart` AS `Incidentcumulatedpending_laststart`,\n `Incident`.`cumulatedpending_stopped` AS `Incidentcumulatedpending_stopped`,\n `Incident`.`tto_started` AS `Incidenttto_started`,\n `Incident`.`tto_laststart` AS `Incidenttto_laststart`,\n `Incident`.`tto_stopped` AS `Incidenttto_stopped`,\n `Incident`.`tto_75_deadline` AS `Incidenttto_75_deadline`,\n `Incident`.`tto_75_passed` AS `Incidenttto_75_passed`,\n `Incident`.`tto_75_triggered` AS `Incidenttto_75_triggered`,\n `Incident`.`tto_75_overrun` AS `Incidenttto_75_overrun`,\n `Incident`.`tto_100_deadline` AS `Incidenttto_100_deadline`,\n `Incident`.`tto_100_passed` AS `Incidenttto_100_passed`,\n `Incident`.`tto_100_triggered` AS `Incidenttto_100_triggered`,\n `Incident`.`tto_100_overrun` AS `Incidenttto_100_overrun`,\n `Incident`.`ttr_started` AS `Incidentttr_started`,\n `Incident`.`ttr_laststart` AS `Incidentttr_laststart`,\n `Incident`.`ttr_stopped` AS `Incidentttr_stopped`,\n `Incident`.`ttr_75_deadline` AS `Incidentttr_75_deadline`,\n `Incident`.`ttr_75_passed` AS `Incidentttr_75_passed`,\n `Incident`.`ttr_75_triggered` AS `Incidentttr_75_triggered`,\n `Incident`.`ttr_75_overrun` AS `Incidentttr_75_overrun`,\n `Incident`.`ttr_100_deadline` AS `Incidentttr_100_deadline`,\n `Incident`.`ttr_100_passed` AS `Incidentttr_100_passed`,\n `Incident`.`ttr_100_triggered` AS `Incidentttr_100_triggered`,\n `Incident`.`ttr_100_overrun` AS `Incidentttr_100_overrun`,\n `Incident`.`public_log_index` AS `Incidentpublic_log_index`,\n `Incident_Ticket`.`description_format` AS `Incidentdescription_format`,\n `Incident_Ticket`.`private_log_index` AS `Incidentprivate_log_index`\n FROM \n   `ticket_incident` AS `Incident`\n   LEFT JOIN \n      `service` AS `Service_service_id`\n    ON `Incident`.`service_id` = `Service_service_id`.`id`\n   LEFT JOIN \n      `servicesubcategory` AS `ServiceSubcategory_servicesubcategory_id`\n    ON `Incident`.`servicesubcategory_id` = `ServiceSubcategory_servicesubcategory_id`.`id`\n   LEFT JOIN \n      `ticket` AS `Incident_parent_incident_id_Ticket`\n    ON `Incident`.`parent_incident_id` = `Incident_parent_incident_id_Ticket`.`id`\n   LEFT JOIN \n      `ticket` AS `Problem_parent_problem_id_Ticket`\n    ON `Incident`.`parent_problem_id` = `Problem_parent_problem_id_Ticket`.`id`\n   LEFT JOIN \n      `ticket` AS `Change_parent_change_id_Ticket`\n    ON `Incident`.`parent_change_id` = `Change_parent_change_id_Ticket`.`id`\n   INNER JOIN (\n      `ticket` AS `Incident_Ticket` \n      INNER JOIN \n         `organization` AS `Organization_org_id`\n       ON `Incident_Ticket`.`org_id` = `Organization_org_id`.`id`\n      LEFT JOIN (\n         `person` AS `Person_caller_id` \n         INNER JOIN \n            `contact` AS `Person_caller_id_Contact`\n          ON `Person_caller_id`.`id` = `Person_caller_id_Contact`.`id`\n      ) ON `Incident_Ticket`.`caller_id` = `Person_caller_id`.`id`\n      LEFT JOIN \n         `contact` AS `Team_team_id_Contact`\n       ON `Incident_Ticket`.`team_id` = `Team_team_id_Contact`.`id`\n      LEFT JOIN (\n         `person` AS `Person_agent_id` \n         INNER JOIN \n            `contact` AS `Person_agent_id_Contact`\n          ON `Person_agent_id`.`id` = `Person_agent_id_Contact`.`id`\n      ) ON `Incident_Ticket`.`agent_id` = `Person_agent_id`.`id`\n   ) ON `Incident`.`id` = `Incident_Ticket`.`id`\n WHERE (((((`Incident`.`id` = \'2\') AND COALESCE((`Team_team_id_Contact`.`finalclass` IN (\'Team\')), 1)) AND COALESCE((`Incident_parent_incident_id_Ticket`.`finalclass` IN (\'Incident\')), 1)) AND COALESCE((`Problem_parent_problem_id_Ticket`.`finalclass` IN (\'Problem\')), 1)) AND COALESCE((`Change_parent_change_id_Ticket`.`finalclass` IN (\'RoutineChange\', \'ApprovedChange\', \'NormalChange\', \'EmergencyChange\', \'Change\')), 1))\n  \'', '2023-05-23 09:29:11', '1', 'EventIssue');

-- --------------------------------------------------------

--
-- Table structure for table `priv_event_email`
--

CREATE TABLE `priv_event_email` (
  `id` int(11) NOT NULL,
  `to` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cc` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bcc` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachments` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_event_issue`
--

CREATE TABLE `priv_event_issue` (
  `id` int(11) NOT NULL,
  `issue` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `impact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `page` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `arguments_post` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `arguments_get` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `callstack` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_event_issue`
--

INSERT INTO `priv_event_issue` (`id`, `issue`, `impact`, `page`, `arguments_post`, `arguments_get`, `callstack`, `data`) VALUES
(1, 'No result for the single row query: \'SELECT\n DISTINCT `Incident`.`id` AS `Incidentid`,\n `Incident_Ticket`.`operational_status` AS `Incidentoperational_status`,\n `Incident_Ticket`.`ref` AS `Incidentref -truncated (8784 chars)', 'Page could not be displayed', '/pages/UI.php', 'a:0:{}', 'a:4:{s:9:\"operation\";s:6:\"delete\";s:5:\"class\";s:8:\"Incident\";s:2:\"id\";s:1:\"2\";s:1:\"c\";a:1:{s:4:\"menu\";s:22:\"Incident:OpenIncidents\";}}', 'a:1:{i:0;a:1:{i:0;s:9294:\"CoreException: No result for the single row query: \'SELECT\n DISTINCT `Incident`.`id` AS `Incidentid`,\n `Incident_Ticket`.`operational_status` AS `Incidentoperational_status`,\n `Incident_Ticket`.`ref` AS `Incidentref`,\n `Incident_Ticket`.`org_id` AS `Incidentorg_id`,\n `Organization_org_id`.`name` AS `Incidentorg_name`,\n `Incident_Ticket`.`caller_id` AS `Incidentcaller_id`,\n `Person_caller_id_Contact`.`name` AS `Incidentcaller_name`,\n `Incident_Ticket`.`team_id` AS `Incidentteam_id`,\n `Team_team_id_Contact`.`email` AS `Incidentteam_name`,\n `Incident_Ticket`.`agent_id` AS `Incidentagent_id`,\n `Person_agent_id_Contact`.`name` AS `Incidentagent_name`,\n `Incident_Ticket`.`title` AS `Incidenttitle`,\n `Incident_Ticket`.`description` AS `Incidentdescription`,\n `Incident_Ticket`.`start_date` AS `Incidentstart_date`,\n `Incident_Ticket`.`end_date` AS `Incidentend_date`,\n `Incident_Ticket`.`last_update` AS `Incidentlast_update`,\n `Incident_Ticket`.`close_date` AS `Incidentclose_date`,\n `Incident_Ticket`.`private_log` AS `Incidentprivate_log`,\n `Incident`.`status` AS `Incidentstatus`,\n `Incident`.`impact` AS `Incidentimpact`,\n `Incident`.`priority` AS `Incidentpriority`,\n `Incident`.`urgency` AS `Incidenturgency`,\n `Incident`.`origin` AS `Incidentorigin`,\n `Incident`.`service_id` AS `Incidentservice_id`,\n `Service_service_id`.`name` AS `Incidentservice_name`,\n `Incident`.`servicesubcategory_id` AS `Incidentservicesubcategory_id`,\n `ServiceSubcategory_servicesubcategory_id`.`name` AS `Incidentservicesubcategory_name`,\n `Incident`.`escalation_flag` AS `Incidentescalation_flag`,\n `Incident`.`escalation_reason` AS `Incidentescalation_reason`,\n `Incident`.`assignment_date` AS `Incidentassignment_date`,\n `Incident`.`resolution_date` AS `Incidentresolution_date`,\n `Incident`.`last_pending_date` AS `Incidentlast_pending_date`,\n `Incident`.`cumulatedpending_timespent` AS `Incidentcumulatedpending`,\n `Incident`.`tto_timespent` AS `Incidenttto`,\n `Incident`.`ttr_timespent` AS `Incidentttr`,\n `Incident`.`tto_100_deadline` AS `Incidenttto_escalation_deadline`,\n `Incident`.`tto_100_passed` AS `Incidentsla_tto_passed`,\n `Incident`.`tto_100_overrun` AS `Incidentsla_tto_over`,\n `Incident`.`ttr_100_deadline` AS `Incidentttr_escalation_deadline`,\n `Incident`.`ttr_100_passed` AS `Incidentsla_ttr_passed`,\n `Incident`.`ttr_100_overrun` AS `Incidentsla_ttr_over`,\n `Incident`.`time_spent` AS `Incidenttime_spent`,\n `Incident`.`resolution_code` AS `Incidentresolution_code`,\n `Incident`.`solution` AS `Incidentsolution`,\n `Incident`.`pending_reason` AS `Incidentpending_reason`,\n `Incident`.`parent_incident_id` AS `Incidentparent_incident_id`,\n `Incident_parent_incident_id_Ticket`.`ref` AS `Incidentparent_incident_ref`,\n `Incident`.`parent_problem_id` AS `Incidentparent_problem_id`,\n `Problem_parent_problem_id_Ticket`.`ref` AS `Incidentparent_problem_ref`,\n `Incident`.`parent_change_id` AS `Incidentparent_change_id`,\n `Change_parent_change_id_Ticket`.`ref` AS `Incidentparent_change_ref`,\n `Incident`.`public_log` AS `Incidentpublic_log`,\n `Incident`.`user_satisfaction` AS `Incidentuser_satisfaction`,\n `Incident`.`user_commment` AS `Incidentuser_comment`,\n `Incident_Ticket`.`finalclass` AS `Incidentfinalclass`,\n CAST(CONCAT(COALESCE(`Incident_Ticket`.`ref`, \'\')) AS CHAR) AS `Incidentfriendlyname`,\n CAST(CONCAT(COALESCE(`Organization_org_id`.`name`, \'\')) AS CHAR) AS `Incidentorg_id_friendlyname`,\n COALESCE((`Organization_org_id`.`status` = \'inactive\'), 0) AS `Incidentorg_id_obsolescence_flag`,\n CAST(CONCAT(COALESCE(`Person_caller_id`.`first_name`, \'\'), COALESCE(\' \', \'\'), COALESCE(`Person_caller_id_Contact`.`name`, \'\')) AS CHAR) AS `Incidentcaller_id_friendlyname`,\n COALESCE((`Person_caller_id_Contact`.`status` = \'inactive\'), 0) AS `Incidentcaller_id_obsolescence_flag`,\n CAST(CONCAT(COALESCE(`Team_team_id_Contact`.`name`, \'\')) AS CHAR) AS `Incidentteam_id_friendlyname`,\n COALESCE((`Team_team_id_Contact`.`status` = \'inactive\'), 0) AS `Incidentteam_id_obsolescence_flag`,\n CAST(CONCAT(COALESCE(`Person_agent_id`.`first_name`, \'\'), COALESCE(\' \', \'\'), COALESCE(`Person_agent_id_Contact`.`name`, \'\')) AS CHAR) AS `Incidentagent_id_friendlyname`,\n COALESCE((`Person_agent_id_Contact`.`status` = \'inactive\'), 0) AS `Incidentagent_id_obsolescence_flag`,\n CAST(CONCAT(COALESCE(`Service_service_id`.`name`, \'\')) AS CHAR) AS `Incidentservice_id_friendlyname`,\n CAST(CONCAT(COALESCE(`ServiceSubcategory_servicesubcategory_id`.`name`, \'\')) AS CHAR) AS `Incidentservicesubcategory_id_friendlyname`,\n CAST(CONCAT(COALESCE(`Incident_parent_incident_id_Ticket`.`ref`, \'\')) AS CHAR) AS `Incidentparent_incident_id_friendlyname`,\n CAST(CONCAT(COALESCE(`Problem_parent_problem_id_Ticket`.`ref`, \'\')) AS CHAR) AS `Incidentparent_problem_id_friendlyname`,\n CAST(CONCAT(COALESCE(`Change_parent_change_id_Ticket`.`ref`, \'\')) AS CHAR) AS `Incidentparent_change_id_friendlyname`,\n `Change_parent_change_id_Ticket`.`finalclass` AS `Incidentparent_change_id_finalclass_recall`,\n `Incident`.`cumulatedpending_started` AS `Incidentcumulatedpending_started`,\n `Incident`.`cumulatedpending_laststart` AS `Incidentcumulatedpending_laststart`,\n `Incident`.`cumulatedpending_stopped` AS `Incidentcumulatedpending_stopped`,\n `Incident`.`tto_started` AS `Incidenttto_started`,\n `Incident`.`tto_laststart` AS `Incidenttto_laststart`,\n `Incident`.`tto_stopped` AS `Incidenttto_stopped`,\n `Incident`.`tto_75_deadline` AS `Incidenttto_75_deadline`,\n `Incident`.`tto_75_passed` AS `Incidenttto_75_passed`,\n `Incident`.`tto_75_triggered` AS `Incidenttto_75_triggered`,\n `Incident`.`tto_75_overrun` AS `Incidenttto_75_overrun`,\n `Incident`.`tto_100_deadline` AS `Incidenttto_100_deadline`,\n `Incident`.`tto_100_passed` AS `Incidenttto_100_passed`,\n `Incident`.`tto_100_triggered` AS `Incidenttto_100_triggered`,\n `Incident`.`tto_100_overrun` AS `Incidenttto_100_overrun`,\n `Incident`.`ttr_started` AS `Incidentttr_started`,\n `Incident`.`ttr_laststart` AS `Incidentttr_laststart`,\n `Incident`.`ttr_stopped` AS `Incidentttr_stopped`,\n `Incident`.`ttr_75_deadline` AS `Incidentttr_75_deadline`,\n `Incident`.`ttr_75_passed` AS `Incidentttr_75_passed`,\n `Incident`.`ttr_75_triggered` AS `Incidentttr_75_triggered`,\n `Incident`.`ttr_75_overrun` AS `Incidentttr_75_overrun`,\n `Incident`.`ttr_100_deadline` AS `Incidentttr_100_deadline`,\n `Incident`.`ttr_100_passed` AS `Incidentttr_100_passed`,\n `Incident`.`ttr_100_triggered` AS `Incidentttr_100_triggered`,\n `Incident`.`ttr_100_overrun` AS `Incidentttr_100_overrun`,\n `Incident`.`public_log_index` AS `Incidentpublic_log_index`,\n `Incident_Ticket`.`description_format` AS `Incidentdescription_format`,\n `Incident_Ticket`.`private_log_index` AS `Incidentprivate_log_index`\n FROM \n   `ticket_incident` AS `Incident`\n   LEFT JOIN \n      `service` AS `Service_service_id`\n    ON `Incident`.`service_id` = `Service_service_id`.`id`\n   LEFT JOIN \n      `servicesubcategory` AS `ServiceSubcategory_servicesubcategory_id`\n    ON `Incident`.`servicesubcategory_id` = `ServiceSubcategory_servicesubcategory_id`.`id`\n   LEFT JOIN \n      `ticket` AS `Incident_parent_incident_id_Ticket`\n    ON `Incident`.`parent_incident_id` = `Incident_parent_incident_id_Ticket`.`id`\n   LEFT JOIN \n      `ticket` AS `Problem_parent_problem_id_Ticket`\n    ON `Incident`.`parent_problem_id` = `Problem_parent_problem_id_Ticket`.`id`\n   LEFT JOIN \n      `ticket` AS `Change_parent_change_id_Ticket`\n    ON `Incident`.`parent_change_id` = `Change_parent_change_id_Ticket`.`id`\n   INNER JOIN (\n      `ticket` AS `Incident_Ticket` \n      INNER JOIN \n         `organization` AS `Organization_org_id`\n       ON `Incident_Ticket`.`org_id` = `Organization_org_id`.`id`\n      LEFT JOIN (\n         `person` AS `Person_caller_id` \n         INNER JOIN \n            `contact` AS `Person_caller_id_Contact`\n          ON `Person_caller_id`.`id` = `Person_caller_id_Contact`.`id`\n      ) ON `Incident_Ticket`.`caller_id` = `Person_caller_id`.`id`\n      LEFT JOIN \n         `contact` AS `Team_team_id_Contact`\n       ON `Incident_Ticket`.`team_id` = `Team_team_id_Contact`.`id`\n      LEFT JOIN (\n         `person` AS `Person_agent_id` \n         INNER JOIN \n            `contact` AS `Person_agent_id_Contact`\n          ON `Person_agent_id`.`id` = `Person_agent_id_Contact`.`id`\n      ) ON `Incident_Ticket`.`agent_id` = `Person_agent_id`.`id`\n   ) ON `Incident`.`id` = `Incident_Ticket`.`id`\n WHERE (((((`Incident`.`id` = \'2\') AND COALESCE((`Team_team_id_Contact`.`finalclass` IN (\'Team\')), 1)) AND COALESCE((`Incident_parent_incident_id_Ticket`.`finalclass` IN (\'Incident\')), 1)) AND COALESCE((`Problem_parent_problem_id_Ticket`.`finalclass` IN (\'Problem\')), 1)) AND COALESCE((`Change_parent_change_id_Ticket`.`finalclass` IN (\'RoutineChange\', \'ApprovedChange\', \'NormalChange\', \'EmergencyChange\', \'Change\')), 1))\n  \' in /home/vol18_2/epizy.com/epiz_33890593/htdocs/core/metamodel.class.php:6935\nStack trace:\n#0 /home/vol18_2/epizy.com/epiz_33890593/htdocs/core/metamodel.class.php(7094): MetaModel::MakeSingleRow(\'Incident\', \'2\', true, false, NULL)\n#1 /home/vol18_2/epizy.com/epiz_33890593/htdocs/core/metamodel.class.php(7020): MetaModel::GetObjectWithArchive(\'Incident\', \'2\', true, false, NULL)\n#2 /home/vol18_2/epizy.com/epiz_33890593/htdocs/pages/UI.php(992): MetaModel::GetObject(\'Incident\', \'2\')\n#3 {main}\";}}', 'a:0:{}');

-- --------------------------------------------------------

--
-- Table structure for table `priv_event_loginusage`
--

CREATE TABLE `priv_event_loginusage` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_event_notification`
--

CREATE TABLE `priv_event_notification` (
  `id` int(11) NOT NULL,
  `trigger_id` int(11) DEFAULT 0,
  `action_id` int(11) DEFAULT 0,
  `object_id` int(11) DEFAULT 0,
  `realclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'EventNotification'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_event_onobject`
--

CREATE TABLE `priv_event_onobject` (
  `id` int(11) NOT NULL,
  `obj_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `obj_key` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_event_restservice`
--

CREATE TABLE `priv_event_restservice` (
  `id` int(11) NOT NULL,
  `operation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `json_input` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` int(11) DEFAULT 0,
  `json_output` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_event_webhook`
--

CREATE TABLE `priv_event_webhook` (
  `id` int(11) NOT NULL,
  `action_finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `webhook_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `headers` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `response` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_event_webservice`
--

CREATE TABLE `priv_event_webservice` (
  `id` int(11) NOT NULL,
  `verb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `result` tinyint(1) DEFAULT 0,
  `log_info` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_warning` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_error` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_extension_install`
--

CREATE TABLE `priv_extension_install` (
  `id` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `installed` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_extension_install`
--

INSERT INTO `priv_extension_install` (`id`, `code`, `label`, `version`, `source`, `installed`) VALUES
(1, 'itop-config-mgmt-core', 'Configuration Management Core', '3.0.2-1', 'datamodels', '2023-03-28 11:35:23'),
(2, 'itop-config-mgmt-datacenter', 'Data Center Devices', '3.0.2-1', 'datamodels', '2023-03-28 11:35:23'),
(3, 'itop-config-mgmt-end-user', 'End-User Devices', '3.0.2-1', 'datamodels', '2023-03-28 11:35:23'),
(4, 'itop-config-mgmt-storage', 'Storage Devices', '3.0.2-1', 'datamodels', '2023-03-28 11:35:23'),
(5, 'itop-config-mgmt-virtualization', 'Virtualization', '3.0.2-1', 'datamodels', '2023-03-28 11:35:23'),
(6, 'itop-service-mgmt-enterprise', 'Service Management for Enterprises', '3.0.2-1', 'datamodels', '2023-03-28 11:35:23'),
(7, 'itop-ticket-mgmt-itil-user-request', 'User Request Management', '3.0.2-1', 'datamodels', '2023-03-28 11:35:23'),
(8, 'itop-ticket-mgmt-itil-incident', 'Incident Management', '3.0.2-1', 'datamodels', '2023-03-28 11:35:23'),
(9, 'itop-ticket-mgmt-itil-enhanced-portal', 'Customer Portal', '3.0.2-1', 'datamodels', '2023-03-28 11:35:23'),
(10, 'itop-ticket-mgmt-itil', 'ITIL Compliant Tickets Management', '3.0.2-1', 'datamodels', '2023-03-28 11:35:23'),
(11, 'itop-change-mgmt-itil', 'ITIL Change Management', '3.0.2-1', 'datamodels', '2023-03-28 11:35:23'),
(12, 'itop-kown-error-mgmt', 'Known Errors Management and FAQ', '3.0.2-1', 'datamodels', '2023-03-28 11:35:23'),
(13, 'itop-problem-mgmt', 'Problem Management', '3.0.2-1', 'datamodels', '2023-03-28 11:35:23');

-- --------------------------------------------------------

--
-- Table structure for table `priv_internaluser`
--

CREATE TABLE `priv_internaluser` (
  `id` int(11) NOT NULL,
  `reset_pwd_token_hash` tinyblob DEFAULT NULL,
  `reset_pwd_token_salt` tinyblob DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'UserInternal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_internaluser`
--

INSERT INTO `priv_internaluser` (`id`, `reset_pwd_token_hash`, `reset_pwd_token_salt`, `finalclass`) VALUES
(1, '', '', 'UserLocal'),
(2, '', '', 'UserLocal');

-- --------------------------------------------------------

--
-- Table structure for table `priv_link_action_trigger`
--

CREATE TABLE `priv_link_action_trigger` (
  `link_id` int(11) NOT NULL,
  `action_id` int(11) DEFAULT 0,
  `trigger_id` int(11) DEFAULT 0,
  `order` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_link_action_trigger`
--

INSERT INTO `priv_link_action_trigger` (`link_id`, `action_id`, `trigger_id`, `order`) VALUES
(1, 1, 1, 0),
(2, 1, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `priv_module_install`
--

CREATE TABLE `priv_module_install` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `installed` datetime DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_module_install`
--

INSERT INTO `priv_module_install` (`id`, `name`, `version`, `installed`, `comment`, `parent_id`) VALUES
(1, 'datamodel', '3.0.2', '2023-03-28 11:35:23', '{\"source_dir\":\"datamodels\\/2.x\\/\"}', 0),
(2, 'iTop', '3.0.2-1-9957', '2023-03-28 11:35:23', 'Done by the setup program\nBuilt on 2022-09-12 14:08:58', 0),
(3, 'authent-cas', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nMandatory\nVisible (during the setup)', 2),
(4, 'authent-external', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)', 2),
(5, 'authent-local', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nMandatory\nVisible (during the setup)', 2),
(6, 'combodo-backoffice-darkmoon-theme', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nMandatory\nHidden (selected automatically)', 2),
(7, 'itop-backup', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nMandatory\nHidden (selected automatically)', 2),
(8, 'itop-config', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nMandatory\nHidden (selected automatically)', 2),
(9, 'itop-files-information', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nHidden (selected automatically)', 2),
(10, 'itop-portal-base', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nMandatory\nHidden (selected automatically)', 2),
(11, 'itop-profiles-itil', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nMandatory\nHidden (selected automatically)', 2),
(12, 'itop-sla-computation', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nMandatory\nHidden (selected automatically)', 2),
(13, 'itop-structure', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nMandatory\nHidden (selected automatically)', 2),
(14, 'itop-welcome-itil', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nMandatory\nHidden (selected automatically)', 2),
(15, 'itop-config-mgmt', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/2.7.1', 2),
(16, 'itop-attachments', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)', 2),
(17, 'itop-tickets', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/2.7.1', 2),
(18, 'combodo-db-tools', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.0.0', 2),
(19, 'combodo-webhook-integration', '1.1.1', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0 || itop-structure/3.0.0\nDepends on module: itop-config/2.7.0', 2),
(20, 'itop-core-update', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-files-information/2.7.0\nDepends on module: combodo-db-tools/2.7.0', 2),
(21, 'itop-hub-connector', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0', 2),
(22, 'itop-oauth-client', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-welcome-itil/3.0.1,', 2),
(23, 'itop-themes-compat', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.0.1', 2),
(24, 'itop-datacenter-mgmt', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0', 2),
(25, 'itop-endusers-devices', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0', 2),
(26, 'itop-storage-mgmt', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0', 2),
(27, 'itop-virtualization-mgmt', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0', 2),
(28, 'itop-bridge-virtualization-storage', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-storage-mgmt/2.2.0\nDepends on module: itop-virtualization-mgmt/2.2.0', 2),
(29, 'itop-service-mgmt', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/2.0.0', 2),
(30, 'itop-bridge-cmdb-ticket', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-tickets/2.7.0\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1', 2),
(31, 'itop-request-mgmt-itil', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/2.4.0', 2),
(32, 'itop-incident-mgmt-itil', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0\nDepends on module: itop-tickets/2.4.0\nDepends on module: itop-profiles-itil/2.3.0', 2),
(33, 'itop-portal', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-portal-base/2.7.0', 2),
(34, 'itop-full-itil', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-request-mgmt-itil/2.3.0\nDepends on module: itop-incident-mgmt-itil/2.3.0', 2),
(35, 'itop-change-mgmt-itil', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0', 2),
(36, 'itop-faq-light', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.0.0 || itop-portal/3.0.0', 2),
(37, 'itop-knownerror-mgmt', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0', 2),
(38, 'itop-problem-mgmt', '3.0.2', '2023-03-28 11:35:23', 'Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/2.0.0', 2);

-- --------------------------------------------------------

--
-- Table structure for table `priv_oauth_client`
--

CREATE TABLE `priv_oauth_client` (
  `id` int(11) NOT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'inactive',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refresh_token` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refresh_token_expiration` datetime DEFAULT NULL,
  `token` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token_expiration` datetime DEFAULT NULL,
  `redirect_url` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'OAuthClient'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_oauth_client_azure`
--

CREATE TABLE `priv_oauth_client_azure` (
  `id` int(11) NOT NULL,
  `scope` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `advanced_scope` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `used_scope` enum('advanced','simple') COLLATE utf8mb4_unicode_ci DEFAULT 'simple',
  `used_for_smtp` enum('no','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_oauth_client_google`
--

CREATE TABLE `priv_oauth_client_google` (
  `id` int(11) NOT NULL,
  `scope` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `advanced_scope` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `used_scope` enum('advanced','simple') COLLATE utf8mb4_unicode_ci DEFAULT 'simple',
  `used_for_smtp` enum('no','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_ownership_token`
--

CREATE TABLE `priv_ownership_token` (
  `id` int(11) NOT NULL,
  `acquired` datetime DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  `obj_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `obj_key` int(11) DEFAULT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `user_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_query`
--

CREATE TABLE `priv_query` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_template` enum('no','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `realclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Query'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_query`
--

INSERT INTO `priv_query` (`id`, `name`, `description`, `is_template`, `realclass`) VALUES
(1, 'Bearbeiter des Tickets', 'Kann in Benachrichtigungen genutzt werden, um den Bearbeiter des Tickets zu verständigen.', 'yes', 'QueryOQL'),
(2, 'Bearbeiter des Tickets, außer der Bearbeiter selbst löst eine Benachrichtigung aus.', 'Kann in Benachrichtigungen genutzt werden, um den Bearbeiter des Tickets zu verständigen.\n      Es wird keine E-Mail gesendet, wenn die auslösende Person der Benachrichtigung der Bearbeiter des Tickets ist.\n    ', 'yes', 'QueryOQL'),
(3, 'Melder und Kontaktliste des Tickets', 'Kann in Benachrichtigungen verwendet werden, um den Melder und alle verknüpften Kontakte eines Tickets zu verständigen.', 'yes', 'QueryOQL'),
(4, 'Melder des Tickets', 'Kann in Benachrichtigungen verwendet werden, um den Melder zu verständigen.', 'yes', 'QueryOQL'),
(5, 'Kontaktliste des Tickets', 'Kann in Benachrichtigungen verwendet werden, um alle verknüpften Kontakte eines Tickets zu verständigen', 'yes', 'QueryOQL'),
(6, 'Manager des Ticketmelders', 'Kann in Benachrichtigungen verwendet werden, um den Manager des Melders eines Tickets zu verständigen.', 'yes', 'QueryOQL'),
(7, 'Auslösende Person einer Benachrichtigung', 'Kann in Benachrichtigungen verwendet werden, um die Person zu verständigen, die über eine Aktion die Benachrichtung auslöste.\n      Wird dieser Befehl allein ausgelöst, wird die Person zurückgegeben, die mit dem angemeldeten Benutzer verknüpft ist, der diesen Befehl ausführt.\n    ', 'yes', 'QueryOQL'),
(8, 'Teammitglieder des Tickets', 'Kann in Benachrichtigungen verwendet werden, um den alle Mitglieder des Teams zu verständigen, an das das Ticket verteilt ist.', 'yes', 'QueryOQL'),
(9, 'Teammitglieder des Tickets, die nicht Bearbeiter sind', 'Kann in Benachrichtigungen verwendet werden, um den alle Mitglieder des Teams zu verständigen, an das das Ticket verteilt ist.\n      Der Bearbeiter des Tickets ist aus dieser Liste ausgeschlossen.\n    ', 'yes', 'QueryOQL'),
(10, 'Team des Tickets', 'Kann in Benachrichtigungen verwendet werden, um das Team, an das das Ticket verteilt ist, über eine hinterlegte Team-Mail-Ad­res­se zu benachrichtigen.', 'yes', 'QueryOQL'),
(11, 'Kontaktliste eines Funktionales CI', 'Kann in Benachrichtigungen verwendet werden, um alle verknüpften Kontakte eines Funktionales CI zu verständigen', 'yes', 'QueryOQL'),
(12, 'Kontaktliste eines Dienstes', 'Kann in Benachrichtigungen verwendet werden, um alle verknüpften Kontakte eines Dienstes zu verständigen', 'yes', 'QueryOQL'),
(13, 'Kontaktliste eines Vertrages', 'Kann in Benachrichtigungen verwendet werden, um alle verknüpften Kontakte eines Vertrages zu verständigen', 'yes', 'QueryOQL');

-- --------------------------------------------------------

--
-- Table structure for table `priv_query_oql`
--

CREATE TABLE `priv_query_oql` (
  `id` int(11) NOT NULL,
  `oql` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_query_oql`
--

INSERT INTO `priv_query_oql` (`id`, `oql`, `fields`) VALUES
(1, 'SELECT Person WHERE id=:this->agent_id', 'id,email'),
(2, 'SELECT Person WHERE id=:this->agent_id AND id != :current_contact_id', 'id,email'),
(3, 'SELECT Contact AS C JOIN lnkContactToTicket AS L ON L.contact_id=C.id WHERE L.ticket_id=:this->id\n      UNION\n      SELECT Person WHERE id=:this->caller_id\n    ', 'id,email'),
(4, 'SELECT Person WHERE id=:this->caller_id', 'id,email'),
(5, 'SELECT Contact AS C JOIN lnkContactToTicket AS L ON L.contact_id=C.id WHERE L.ticket_id=:this->id', 'id,email'),
(6, 'SELECT Person AS manager JOIN Person AS employee ON employee.manager_id = manager.id WHERE employee.id=:this->caller_id', 'id,email'),
(7, 'SELECT Person WHERE id = :current_contact_id', 'id,email'),
(8, 'SELECT Person AS P JOIN lnkPersonToTeam AS L ON L.person_id=P.id\n      WHERE L.team_id = :this->team_id\n    ', 'id,email'),
(9, 'SELECT Person AS P JOIN lnkPersonToTeam AS L ON L.person_id=P.id\n      WHERE L.team_id = :this->team_id AND P.id != :this->agent_id\n    ', 'id,email'),
(10, 'SELECT Team WHERE id = :this->team_id', 'id,email'),
(11, 'SELECT Contact AS C JOIN lnkContactToFunctionalCI AS L ON L.contact_id=C.id\n      WHERE L.functionalci_id = :this->id\n    ', 'id,email'),
(12, 'SELECT Contact AS C JOIN lnkContactToService AS L ON L.contact_id=C.id\n      WHERE L.service_id = :this->id\n    ', 'id,email'),
(13, 'SELECT Contact AS C JOIN lnkContactToContract AS L ON L.contact_id=C.id\n      WHERE L.contract_id = :this->id\n    ', 'id,email');

-- --------------------------------------------------------

--
-- Table structure for table `priv_shortcut`
--

CREATE TABLE `priv_shortcut` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT 0,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `context` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `realclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Shortcut'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_shortcut_oql`
--

CREATE TABLE `priv_shortcut_oql` (
  `id` int(11) NOT NULL,
  `oql` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_reload` enum('custom','none') COLLATE utf8mb4_unicode_ci DEFAULT 'none',
  `auto_reload_sec` int(11) DEFAULT 60
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_sync_att`
--

CREATE TABLE `priv_sync_att` (
  `id` int(11) NOT NULL,
  `sync_source_id` int(11) DEFAULT 0,
  `attcode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `update` tinyint(1) DEFAULT 1,
  `reconcile` tinyint(1) DEFAULT 0,
  `update_policy` enum('master_locked','master_unlocked','write_if_empty') COLLATE utf8mb4_unicode_ci DEFAULT 'master_locked',
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'SynchroAttribute'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_sync_att_extkey`
--

CREATE TABLE `priv_sync_att_extkey` (
  `id` int(11) NOT NULL,
  `reconciliation_attcode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_sync_att_linkset`
--

CREATE TABLE `priv_sync_att_linkset` (
  `id` int(11) NOT NULL,
  `row_separator` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '|',
  `attribute_separator` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ';',
  `value_separator` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ':',
  `attribute_qualifier` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_sync_datasource`
--

CREATE TABLE `priv_sync_datasource` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('implementation','obsolete','production') COLLATE utf8mb4_unicode_ci DEFAULT 'implementation',
  `user_id` int(11) DEFAULT 0,
  `notify_contact_id` int(11) DEFAULT 0,
  `scope_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'lnkTriggerAction',
  `database_table_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `scope_restriction` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `full_load_periodicity` int(11) UNSIGNED DEFAULT NULL,
  `reconciliation_policy` enum('use_attributes','use_primary_key') COLLATE utf8mb4_unicode_ci DEFAULT 'use_attributes',
  `action_on_zero` enum('create','error') COLLATE utf8mb4_unicode_ci DEFAULT 'create',
  `action_on_one` enum('error','update') COLLATE utf8mb4_unicode_ci DEFAULT 'update',
  `action_on_multiple` enum('create','error','take_first') COLLATE utf8mb4_unicode_ci DEFAULT 'error',
  `delete_policy` enum('delete','ignore','update','update_then_delete') COLLATE utf8mb4_unicode_ci DEFAULT 'ignore',
  `delete_policy_update` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `delete_policy_retention` int(11) UNSIGNED DEFAULT NULL,
  `user_delete_policy` enum('administrators','everybody','nobody') COLLATE utf8mb4_unicode_ci DEFAULT 'nobody',
  `url_icon` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `url_application` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_sync_log`
--

CREATE TABLE `priv_sync_log` (
  `id` int(11) NOT NULL,
  `sync_source_id` int(11) DEFAULT 0,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `status` enum('completed','error','running') COLLATE utf8mb4_unicode_ci DEFAULT 'running',
  `status_curr_job` int(11) DEFAULT 0,
  `status_curr_pos` int(11) DEFAULT 0,
  `stats_nb_replica_seen` int(11) DEFAULT 0,
  `stats_nb_replica_total` int(11) DEFAULT 0,
  `stats_nb_obj_deleted` int(11) DEFAULT 0,
  `stats_deleted_errors` int(11) DEFAULT 0,
  `stats_nb_obj_obsoleted` int(11) DEFAULT 0,
  `stats_nb_obj_obsoleted_errors` int(11) DEFAULT 0,
  `stats_nb_obj_created` int(11) DEFAULT 0,
  `stats_nb_obj_created_errors` int(11) DEFAULT 0,
  `stats_nb_obj_created_warnings` int(11) DEFAULT 0,
  `stats_nb_obj_updated` int(11) DEFAULT 0,
  `stats_nb_obj_updated_errors` int(11) DEFAULT 0,
  `stats_nb_obj_updated_warnings` int(11) DEFAULT 0,
  `stats_nb_obj_unchanged_warnings` int(11) DEFAULT 0,
  `stats_nb_replica_reconciled_errors` int(11) DEFAULT 0,
  `stats_nb_replica_disappeared_no_action` int(11) DEFAULT 0,
  `stats_nb_obj_new_updated` int(11) DEFAULT 0,
  `stats_nb_obj_new_updated_warnings` int(11) DEFAULT 0,
  `stats_nb_obj_new_unchanged` int(11) DEFAULT 0,
  `stats_nb_obj_new_unchanged_warnings` int(11) DEFAULT 0,
  `last_error` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `traces` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `memory_usage_peak` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_sync_replica`
--

CREATE TABLE `priv_sync_replica` (
  `id` int(11) NOT NULL,
  `sync_source_id` int(11) DEFAULT 0,
  `dest_id` int(11) DEFAULT 0,
  `dest_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Organization',
  `status_last_seen` datetime DEFAULT NULL,
  `status` enum('modified','new','obsolete','orphan','synchronized') COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `status_dest_creator` tinyint(1) DEFAULT 0,
  `status_last_error` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status_last_warning` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `info_creation_date` datetime DEFAULT NULL,
  `info_last_modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_tagfielddata`
--

CREATE TABLE `priv_tagfielddata` (
  `id` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obj_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `obj_attcode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'TagSetFieldData'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_trigger`
--

CREATE TABLE `priv_trigger` (
  `id` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `context` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `realclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Trigger'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_trigger`
--

INSERT INTO `priv_trigger` (`id`, `description`, `context`, `realclass`) VALUES
(1, 'Person mentioned on Ticket', '', 'TriggerOnObjectMention'),
(2, 'Person mentioned on WorkOrder', '', 'TriggerOnObjectMention');

-- --------------------------------------------------------

--
-- Table structure for table `priv_trigger_onobjcreate`
--

CREATE TABLE `priv_trigger_onobjcreate` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_trigger_onobjdelete`
--

CREATE TABLE `priv_trigger_onobjdelete` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_trigger_onobject`
--

CREATE TABLE `priv_trigger_onobject` (
  `id` int(11) NOT NULL,
  `target_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'OtherSoftware',
  `filter` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `realclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'TriggerOnObject'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_trigger_onobject`
--

INSERT INTO `priv_trigger_onobject` (`id`, `target_class`, `filter`, `realclass`) VALUES
(1, 'Ticket', NULL, 'TriggerOnObjectMention'),
(2, 'WorkOrder', NULL, 'TriggerOnObjectMention');

-- --------------------------------------------------------

--
-- Table structure for table `priv_trigger_onobjmention`
--

CREATE TABLE `priv_trigger_onobjmention` (
  `id` int(11) NOT NULL,
  `mentioned_filter` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_trigger_onobjmention`
--

INSERT INTO `priv_trigger_onobjmention` (`id`, `mentioned_filter`) VALUES
(1, 'SELECT `Person` FROM Person AS `Person` WHERE ((`status` = \'active\') AND ((`org_id` = :current_contact->org_id) OR (`org_id` = :this->org_id)))'),
(2, 'SELECT `Person` FROM Person AS `Person` WHERE ((`status` = \'active\') AND (`org_id` = :current_contact->org_id))');

-- --------------------------------------------------------

--
-- Table structure for table `priv_trigger_onobjupdate`
--

CREATE TABLE `priv_trigger_onobjupdate` (
  `id` int(11) NOT NULL,
  `target_attcodes` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_trigger_onportalupdate`
--

CREATE TABLE `priv_trigger_onportalupdate` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_trigger_onstatechange`
--

CREATE TABLE `priv_trigger_onstatechange` (
  `id` int(11) NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `realclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'TriggerOnStateChange'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_trigger_onstateenter`
--

CREATE TABLE `priv_trigger_onstateenter` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_trigger_onstateleave`
--

CREATE TABLE `priv_trigger_onstateleave` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_trigger_threshold`
--

CREATE TABLE `priv_trigger_threshold` (
  `id` int(11) NOT NULL,
  `stop_watch_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `threshold_index` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_urp_profiles`
--

CREATE TABLE `priv_urp_profiles` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_urp_profiles`
--

INSERT INTO `priv_urp_profiles` (`id`, `name`, `description`) VALUES
(1, 'Administrator', 'Has the rights on everything (bypassing any control)'),
(2, 'Portal user', 'Has the rights to access to the user portal. People having this profile will not be allowed to access the standard application, they will be automatically redirected to the user portal.'),
(3, 'Configuration Manager', 'Person in charge of the documentation of the managed CIs'),
(4, 'Service Desk Agent', 'Person in charge of creating incident reports'),
(5, 'Support Agent', 'Person analyzing and solving the current incidents'),
(6, 'Problem Manager', 'Person analyzing and solving the current problems'),
(7, 'Change Implementor', 'Person executing the changes'),
(8, 'Change Supervisor', 'Person responsible for the overall change execution'),
(9, 'Change Approver', 'Person who could be impacted by some changes'),
(10, 'Service Manager', 'Person responsible for the service delivered to the [internal] customer'),
(11, 'Document author', 'Any person who could contribute to documentation'),
(12, 'Portal power user', 'Users having this profile will have the rights to see all the tickets for a customer in the portal. Must be used in conjunction with other profiles (e.g. Portal User).'),
(1024, 'REST Services User', 'Only users having this profile are allowed to use the REST Web Services (unless \'secure_rest_services\' is set to false\n          in the configuration file).\n        ');

-- --------------------------------------------------------

--
-- Table structure for table `priv_urp_userorg`
--

CREATE TABLE `priv_urp_userorg` (
  `id` int(11) NOT NULL,
  `userid` int(11) DEFAULT 0,
  `allowed_org_id` int(11) DEFAULT 0,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `priv_urp_userprofile`
--

CREATE TABLE `priv_urp_userprofile` (
  `id` int(11) NOT NULL,
  `userid` int(11) DEFAULT 0,
  `profileid` int(11) DEFAULT 0,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_urp_userprofile`
--

INSERT INTO `priv_urp_userprofile` (`id`, `userid`, `profileid`, `description`) VALUES
(1, 1, 1, 'By definition, the administrator must have the administrator profile'),
(2, 1, 1024, 'Geile Sau'),
(3, 2, 1024, 'for api');

-- --------------------------------------------------------

--
-- Table structure for table `priv_user`
--

CREATE TABLE `priv_user` (
  `id` int(11) NOT NULL,
  `contactid` int(11) DEFAULT 0,
  `login` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `language` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'EN US',
  `status` enum('disabled','enabled') COLLATE utf8mb4_unicode_ci DEFAULT 'enabled',
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'User'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_user`
--

INSERT INTO `priv_user` (`id`, `contactid`, `login`, `language`, `status`, `finalclass`) VALUES
(1, 1, 'admin', 'DE DE', 'enabled', 'UserLocal'),
(2, 2, 'api', 'EN US', 'enabled', 'UserLocal');

-- --------------------------------------------------------

--
-- Table structure for table `priv_user_local`
--

CREATE TABLE `priv_user_local` (
  `id` int(11) NOT NULL,
  `password_hash` tinyblob DEFAULT NULL,
  `password_salt` tinyblob DEFAULT NULL,
  `expiration` enum('can_expire','force_expire','never_expire','otp_expire') COLLATE utf8mb4_unicode_ci DEFAULT 'never_expire',
  `password_renewed_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priv_user_local`
--

INSERT INTO `priv_user_local` (`id`, `password_hash`, `password_salt`, `expiration`, `password_renewed_date`) VALUES
(1, 0x2432792431302457617a46615a6c2f6444744361525565644d4647774f743550474156772f6e43784b5666705a716b4764344a617a6467516f553879, '', 'never_expire', '2023-03-28'),
(2, 0x243279243130245a7548766e74354a43773172346e46676d4a454156752e66752f4c66474464476c6b2f64384e4574792f4b32504e35575978324a79, '', 'never_expire', '2023-04-04');

-- --------------------------------------------------------

--
-- Table structure for table `providercontract`
--

CREATE TABLE `providercontract` (
  `id` int(11) NOT NULL,
  `sla` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `coverage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rack`
--

CREATE TABLE `rack` (
  `id` int(11) NOT NULL,
  `nb_u` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `remoteapplicationconnection`
--

CREATE TABLE `remoteapplicationconnection` (
  `id` int(11) NOT NULL,
  `remoteapplicationtype_id` int(11) DEFAULT 0,
  `environment` enum('1-development','2-test','3-production') COLLATE utf8mb4_unicode_ci DEFAULT '2-test',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'RemoteApplicationConnection'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `remoteapplicationtype`
--

CREATE TABLE `remoteapplicationtype` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `remoteapplicationtype`
--

INSERT INTO `remoteapplicationtype` (`id`) VALUES
(1),
(2),
(3),
(4),
(5);

-- --------------------------------------------------------

--
-- Table structure for table `remoteitopconnection`
--

CREATE TABLE `remoteitopconnection` (
  `id` int(11) NOT NULL,
  `auth_user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `auth_pwd` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '1.3'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sanswitch`
--

CREATE TABLE `sanswitch` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `server`
--

CREATE TABLE `server` (
  `id` int(11) NOT NULL,
  `osfamily_id` int(11) DEFAULT 0,
  `osversion_id` int(11) DEFAULT 0,
  `oslicence_id` int(11) DEFAULT 0,
  `cpu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT 0,
  `servicefamily_id` int(11) DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('implementation','obsolete','production') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_data` longblob DEFAULT NULL,
  `icon_mimetype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `name`, `org_id`, `servicefamily_id`, `description`, `status`, `icon_data`, `icon_mimetype`, `icon_filename`) VALUES
(1, 'bla', 1, 0, '', NULL, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `servicefamily`
--

CREATE TABLE `servicefamily` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `icon_data` longblob DEFAULT NULL,
  `icon_mimetype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `servicesubcategory`
--

CREATE TABLE `servicesubcategory` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_id` int(11) DEFAULT 0,
  `request_type` enum('incident','service_request') COLLATE utf8mb4_unicode_ci DEFAULT 'incident',
  `status` enum('implementation','obsolete','production') COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sla`
--

CREATE TABLE `sla` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `org_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `slt`
--

CREATE TABLE `slt` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `priority` enum('1','2','3','4') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_type` enum('incident','service_request') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metric` enum('tto','ttr') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `unit` enum('hours','minutes') COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `software`
--

CREATE TABLE `software` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `vendor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` enum('DBServer','Middleware','OtherSoftware','PCSoftware','WebServer') COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `softwareinstance`
--

CREATE TABLE `softwareinstance` (
  `id` int(11) NOT NULL,
  `functionalci_id` int(11) DEFAULT 0,
  `software_id` int(11) DEFAULT 0,
  `softwarelicence_id` int(11) DEFAULT 0,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'SoftwareInstance'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `softwarelicence`
--

CREATE TABLE `softwarelicence` (
  `id` int(11) NOT NULL,
  `software_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `softwarepatch`
--

CREATE TABLE `softwarepatch` (
  `id` int(11) NOT NULL,
  `software_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `storagesystem`
--

CREATE TABLE `storagesystem` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subnet`
--

CREATE TABLE `subnet` (
  `id` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subnet_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT 0,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ip_mask` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tablet`
--

CREATE TABLE `tablet` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tape`
--

CREATE TABLE `tape` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `tapelibrary_id` int(11) DEFAULT 0,
  `obsolescence_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tapelibrary`
--

CREATE TABLE `tapelibrary` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `telephonyci`
--

CREATE TABLE `telephonyci` (
  `id` int(11) NOT NULL,
  `phonenumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'TelephonyCI'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `id` int(11) NOT NULL,
  `operational_status` enum('closed','ongoing','resolved') COLLATE utf8mb4_unicode_ci DEFAULT 'ongoing',
  `ref` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT 0,
  `caller_id` int(11) DEFAULT 0,
  `team_id` int(11) DEFAULT 0,
  `agent_id` int(11) DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_format` enum('text','html') COLLATE utf8mb4_unicode_ci DEFAULT 'text',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `close_date` datetime DEFAULT NULL,
  `private_log` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `private_log_index` blob DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Ticket'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`id`, `operational_status`, `ref`, `org_id`, `caller_id`, `team_id`, `agent_id`, `title`, `description`, `description_format`, `start_date`, `end_date`, `last_update`, `close_date`, `private_log`, `private_log_index`, `finalclass`) VALUES
(1, 'ongoing', 'I-000001', 1, 1, 0, 0, 'test', '<p>this is a test</p>', 'html', '2023-04-04 10:01:22', NULL, '2023-04-04 10:01:22', NULL, '', 0x613a303a7b7d, 'Incident'),
(5, 'ongoing', 'I-000006', 1, 2, 0, 0, 'Un Problemo!', '<p>Ayyy...</p>', 'html', '2023-05-23 09:45:44', NULL, '2023-05-23 09:45:44', NULL, '', 0x613a303a7b7d, 'Incident'),
(6, 'ongoing', 'I-000007', 1, 2, 0, 0, 'Un Problemo!', '<p>Ayyy...</p>', 'html', '2023-05-23 10:02:05', NULL, '2023-05-23 10:02:05', NULL, '', 0x613a303a7b7d, 'Incident'),
(7, 'ongoing', 'I-000008', 1, 2, 0, 0, 'Device 1 - DOWN', '<p>MySQL is down!</p>', 'html', '2023-05-23 10:33:38', NULL, '2023-05-23 10:33:38', NULL, '', 0x613a303a7b7d, 'Incident'),
(8, 'ongoing', 'I-000009', 1, 2, 0, 0, 'Device 2345 - UP', '<p>MySQL is up!</p>', 'html', '2023-05-23 10:34:51', NULL, '2023-05-23 10:34:51', NULL, '', 0x613a303a7b7d, 'Incident'),
(9, 'ongoing', 'I-000010', 1, 2, 0, 0, 'Device asdfasdf - DOWM', '<p>MySQL is up!</p>', 'html', '2023-05-23 11:19:51', NULL, '2023-05-23 11:19:51', NULL, '', 0x613a303a7b7d, 'Incident');

-- --------------------------------------------------------

--
-- Table structure for table `ticket_incident`
--

CREATE TABLE `ticket_incident` (
  `id` int(11) NOT NULL,
  `status` enum('assigned','closed','escalated_tto','escalated_ttr','new','pending','resolved') COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `impact` enum('1','2','3') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `priority` enum('1','2','3','4') COLLATE utf8mb4_unicode_ci DEFAULT '4',
  `urgency` enum('1','2','3','4') COLLATE utf8mb4_unicode_ci DEFAULT '4',
  `origin` enum('mail','monitoring','phone','portal') COLLATE utf8mb4_unicode_ci DEFAULT 'phone',
  `service_id` int(11) DEFAULT 0,
  `servicesubcategory_id` int(11) DEFAULT 0,
  `escalation_flag` enum('no','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `escalation_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  `last_pending_date` datetime DEFAULT NULL,
  `cumulatedpending_timespent` int(11) UNSIGNED DEFAULT NULL,
  `cumulatedpending_started` datetime DEFAULT NULL,
  `cumulatedpending_laststart` datetime DEFAULT NULL,
  `cumulatedpending_stopped` datetime DEFAULT NULL,
  `tto_timespent` int(11) UNSIGNED DEFAULT NULL,
  `tto_started` datetime DEFAULT NULL,
  `tto_laststart` datetime DEFAULT NULL,
  `tto_stopped` datetime DEFAULT NULL,
  `tto_75_deadline` datetime DEFAULT NULL,
  `tto_75_passed` tinyint(1) UNSIGNED DEFAULT NULL,
  `tto_75_triggered` tinyint(1) DEFAULT NULL,
  `tto_75_overrun` int(11) UNSIGNED DEFAULT NULL,
  `tto_100_deadline` datetime DEFAULT NULL,
  `tto_100_passed` tinyint(1) UNSIGNED DEFAULT NULL,
  `tto_100_triggered` tinyint(1) DEFAULT NULL,
  `tto_100_overrun` int(11) UNSIGNED DEFAULT NULL,
  `ttr_timespent` int(11) UNSIGNED DEFAULT NULL,
  `ttr_started` datetime DEFAULT NULL,
  `ttr_laststart` datetime DEFAULT NULL,
  `ttr_stopped` datetime DEFAULT NULL,
  `ttr_75_deadline` datetime DEFAULT NULL,
  `ttr_75_passed` tinyint(1) UNSIGNED DEFAULT NULL,
  `ttr_75_triggered` tinyint(1) DEFAULT NULL,
  `ttr_75_overrun` int(11) UNSIGNED DEFAULT NULL,
  `ttr_100_deadline` datetime DEFAULT NULL,
  `ttr_100_passed` tinyint(1) UNSIGNED DEFAULT NULL,
  `ttr_100_triggered` tinyint(1) DEFAULT NULL,
  `ttr_100_overrun` int(11) UNSIGNED DEFAULT NULL,
  `time_spent` int(11) UNSIGNED DEFAULT NULL,
  `resolution_code` enum('assistance','bug fixed','hardware repair','other','software patch','system update','training') COLLATE utf8mb4_unicode_ci DEFAULT 'assistance',
  `solution` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pending_reason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_incident_id` int(11) DEFAULT 0,
  `parent_problem_id` int(11) DEFAULT 0,
  `parent_change_id` int(11) DEFAULT 0,
  `public_log` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `public_log_index` blob DEFAULT NULL,
  `user_satisfaction` enum('1','2','3','4') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `user_commment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ticket_incident`
--

INSERT INTO `ticket_incident` (`id`, `status`, `impact`, `priority`, `urgency`, `origin`, `service_id`, `servicesubcategory_id`, `escalation_flag`, `escalation_reason`, `assignment_date`, `resolution_date`, `last_pending_date`, `cumulatedpending_timespent`, `cumulatedpending_started`, `cumulatedpending_laststart`, `cumulatedpending_stopped`, `tto_timespent`, `tto_started`, `tto_laststart`, `tto_stopped`, `tto_75_deadline`, `tto_75_passed`, `tto_75_triggered`, `tto_75_overrun`, `tto_100_deadline`, `tto_100_passed`, `tto_100_triggered`, `tto_100_overrun`, `ttr_timespent`, `ttr_started`, `ttr_laststart`, `ttr_stopped`, `ttr_75_deadline`, `ttr_75_passed`, `ttr_75_triggered`, `ttr_75_overrun`, `ttr_100_deadline`, `ttr_100_passed`, `ttr_100_triggered`, `ttr_100_overrun`, `time_spent`, `resolution_code`, `solution`, `pending_reason`, `parent_incident_id`, `parent_problem_id`, `parent_change_id`, `public_log`, `public_log_index`, `user_satisfaction`, `user_commment`) VALUES
(1, 'new', '1', '4', '4', 'phone', 0, 0, 'no', '', NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, '2023-04-04 10:01:22', '2023-04-04 10:01:22', NULL, NULL, 0, 0, NULL, NULL, 0, 0, NULL, 0, '2023-04-04 10:01:22', '2023-04-04 10:01:22', NULL, NULL, 0, 0, NULL, NULL, 0, 0, NULL, NULL, 'assistance', '', '', 0, 0, 0, '', 0x613a303a7b7d, '1', ''),
(5, 'new', '1', '1', '1', 'monitoring', 0, 0, 'no', '', NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, '2023-05-23 09:45:44', '2023-05-23 09:45:44', NULL, NULL, 0, 0, NULL, NULL, 0, 0, NULL, 0, '2023-05-23 09:45:44', '2023-05-23 09:45:44', NULL, NULL, 0, 0, NULL, NULL, 0, 0, NULL, NULL, 'assistance', '', '', 0, 0, 0, '', 0x613a303a7b7d, '1', ''),
(6, 'new', '1', '1', '1', 'monitoring', 0, 0, 'no', '', NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, '2023-05-23 10:02:05', '2023-05-23 10:02:05', NULL, NULL, 0, 0, NULL, NULL, 0, 0, NULL, 0, '2023-05-23 10:02:05', '2023-05-23 10:02:05', NULL, NULL, 0, 0, NULL, NULL, 0, 0, NULL, NULL, 'assistance', '', '', 0, 0, 0, '', 0x613a303a7b7d, '1', ''),
(7, 'new', '1', '1', '1', 'monitoring', 0, 0, 'no', '', NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, '2023-05-23 10:33:38', '2023-05-23 10:33:38', NULL, NULL, 0, 0, NULL, NULL, 0, 0, NULL, 0, '2023-05-23 10:33:38', '2023-05-23 10:33:38', NULL, NULL, 0, 0, NULL, NULL, 0, 0, NULL, NULL, 'assistance', '', '', 0, 0, 0, '', 0x613a303a7b7d, '1', ''),
(8, 'new', '1', '1', '1', 'monitoring', 0, 0, 'no', '', NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, '2023-05-23 10:34:51', '2023-05-23 10:34:51', NULL, NULL, 0, 0, NULL, NULL, 0, 0, NULL, 0, '2023-05-23 10:34:51', '2023-05-23 10:34:51', NULL, NULL, 0, 0, NULL, NULL, 0, 0, NULL, NULL, 'assistance', '', '', 0, 0, 0, '', 0x613a303a7b7d, '1', ''),
(9, 'new', '1', '1', '1', 'monitoring', 0, 0, 'no', '', NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, '2023-05-23 11:19:51', '2023-05-23 11:19:51', NULL, NULL, 0, 0, NULL, NULL, 0, 0, NULL, 0, '2023-05-23 11:19:51', '2023-05-23 11:19:51', NULL, NULL, 0, 0, NULL, NULL, 0, 0, NULL, NULL, 'assistance', '', '', 0, 0, 0, '', 0x613a303a7b7d, '1', '');

-- --------------------------------------------------------

--
-- Table structure for table `ticket_problem`
--

CREATE TABLE `ticket_problem` (
  `id` int(11) NOT NULL,
  `status` enum('assigned','closed','new','resolved') COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `service_id` int(11) DEFAULT 0,
  `servicesubcategory_id` int(11) DEFAULT 0,
  `product` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `impact` enum('1','2','3') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `urgency` enum('1','2','3','4') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `priority` enum('1','2','3','4') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `related_change_id` int(11) DEFAULT 0,
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_request`
--

CREATE TABLE `ticket_request` (
  `id` int(11) NOT NULL,
  `status` enum('approved','assigned','closed','escalated_tto','escalated_ttr','new','pending','rejected','resolved','waiting_for_approval') COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `request_type` enum('service_request') COLLATE utf8mb4_unicode_ci DEFAULT 'service_request',
  `impact` enum('1','2','3') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `priority` enum('1','2','3','4') COLLATE utf8mb4_unicode_ci DEFAULT '4',
  `urgency` enum('1','2','3','4') COLLATE utf8mb4_unicode_ci DEFAULT '4',
  `origin` enum('mail','phone','portal') COLLATE utf8mb4_unicode_ci DEFAULT 'phone',
  `approver_id` int(11) DEFAULT 0,
  `service_id` int(11) DEFAULT 0,
  `servicesubcategory_id` int(11) DEFAULT 0,
  `escalation_flag` enum('no','yes') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `escalation_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  `last_pending_date` datetime DEFAULT NULL,
  `cumulatedpending_timespent` int(11) UNSIGNED DEFAULT NULL,
  `cumulatedpending_started` datetime DEFAULT NULL,
  `cumulatedpending_laststart` datetime DEFAULT NULL,
  `cumulatedpending_stopped` datetime DEFAULT NULL,
  `tto_timespent` int(11) UNSIGNED DEFAULT NULL,
  `tto_started` datetime DEFAULT NULL,
  `tto_laststart` datetime DEFAULT NULL,
  `tto_stopped` datetime DEFAULT NULL,
  `tto_75_deadline` datetime DEFAULT NULL,
  `tto_75_passed` tinyint(1) UNSIGNED DEFAULT NULL,
  `tto_75_triggered` tinyint(1) DEFAULT NULL,
  `tto_75_overrun` int(11) UNSIGNED DEFAULT NULL,
  `tto_100_deadline` datetime DEFAULT NULL,
  `tto_100_passed` tinyint(1) UNSIGNED DEFAULT NULL,
  `tto_100_triggered` tinyint(1) DEFAULT NULL,
  `tto_100_overrun` int(11) UNSIGNED DEFAULT NULL,
  `ttr_timespent` int(11) UNSIGNED DEFAULT NULL,
  `ttr_started` datetime DEFAULT NULL,
  `ttr_laststart` datetime DEFAULT NULL,
  `ttr_stopped` datetime DEFAULT NULL,
  `ttr_75_deadline` datetime DEFAULT NULL,
  `ttr_75_passed` tinyint(1) UNSIGNED DEFAULT NULL,
  `ttr_75_triggered` tinyint(1) DEFAULT NULL,
  `ttr_75_overrun` int(11) UNSIGNED DEFAULT NULL,
  `ttr_100_deadline` datetime DEFAULT NULL,
  `ttr_100_passed` tinyint(1) UNSIGNED DEFAULT NULL,
  `ttr_100_triggered` tinyint(1) DEFAULT NULL,
  `ttr_100_overrun` int(11) UNSIGNED DEFAULT NULL,
  `time_spent` int(11) UNSIGNED DEFAULT NULL,
  `resolution_code` enum('assistance','bug fixed','hardware repair','other','software patch','system update','training') COLLATE utf8mb4_unicode_ci DEFAULT 'assistance',
  `solution` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pending_reason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_request_id` int(11) DEFAULT 0,
  `parent_incident_id` int(11) DEFAULT 0,
  `parent_problem_id` int(11) DEFAULT 0,
  `parent_change_id` int(11) DEFAULT 0,
  `public_log` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `public_log_index` blob DEFAULT NULL,
  `user_satisfaction` enum('1','2','3','4') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `user_commment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `typology`
--

CREATE TABLE `typology` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Typology'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `typology`
--

INSERT INTO `typology` (`id`, `name`, `finalclass`) VALUES
(1, 'iTop', 'RemoteApplicationType'),
(2, 'Slack', 'RemoteApplicationType'),
(3, 'Rocket.Chat', 'RemoteApplicationType'),
(4, 'Google Chat', 'RemoteApplicationType'),
(5, 'Microsoft Teams', 'RemoteApplicationType'),
(6, 'test', 'NetworkDeviceType');

-- --------------------------------------------------------

--
-- Table structure for table `virtualdevice`
--

CREATE TABLE `virtualdevice` (
  `id` int(11) NOT NULL,
  `status` enum('implementation','obsolete','production','stock') COLLATE utf8mb4_unicode_ci DEFAULT 'production',
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'VirtualDevice'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `virtualhost`
--

CREATE TABLE `virtualhost` (
  `id` int(11) NOT NULL,
  `finalclass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'VirtualHost'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `virtualmachine`
--

CREATE TABLE `virtualmachine` (
  `id` int(11) NOT NULL,
  `virtualhost_id` int(11) DEFAULT 0,
  `osfamily_id` int(11) DEFAULT 0,
  `osversion_id` int(11) DEFAULT 0,
  `oslicence_id` int(11) DEFAULT 0,
  `cpu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `managementip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vlan`
--

CREATE TABLE `vlan` (
  `id` int(11) NOT NULL,
  `vlan_tag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `org_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `webapplication`
--

CREATE TABLE `webapplication` (
  `id` int(11) NOT NULL,
  `webserver_id` int(11) DEFAULT 0,
  `url` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `webserver`
--

CREATE TABLE `webserver` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `workorder`
--

CREATE TABLE `workorder` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('closed','open') COLLATE utf8mb4_unicode_ci DEFAULT 'open',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ticket_id` int(11) DEFAULT 0,
  `team_id` int(11) DEFAULT 0,
  `owner_id` int(11) DEFAULT 0,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `log` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_index` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applicationsolution`
--
ALTER TABLE `applicationsolution`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attachment`
--
ALTER TABLE `attachment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `temp_id` (`temp_id`(95)),
  ADD KEY `item_class` (`item_class`(95)),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `item_class_item_id` (`item_class`(95),`item_id`),
  ADD KEY `item_org_id` (`item_org_id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `businessprocess`
--
ALTER TABLE `businessprocess`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `change`
--
ALTER TABLE `change`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requestor_id` (`requestor_id`),
  ADD KEY `supervisor_group_id` (`supervisor_group_id`),
  ADD KEY `supervisor_id` (`supervisor_id`),
  ADD KEY `manager_group_id` (`manager_group_id`),
  ADD KEY `manager_id` (`manager_id`),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `change_approved`
--
ALTER TABLE `change_approved`
  ADD PRIMARY KEY (`id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `change_emergency`
--
ALTER TABLE `change_emergency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `change_normal`
--
ALTER TABLE `change_normal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `change_routine`
--
ALTER TABLE `change_routine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `connectableci`
--
ALTER TABLE `connectableci`
  ADD PRIMARY KEY (`id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `org_id` (`org_id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `contacttype`
--
ALTER TABLE `contacttype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contract`
--
ALTER TABLE `contract`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `org_id` (`org_id`),
  ADD KEY `contracttype_id` (`contracttype_id`),
  ADD KEY `provider_id` (`provider_id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `contracttype`
--
ALTER TABLE `contracttype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customercontract`
--
ALTER TABLE `customercontract`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `databaseschema`
--
ALTER TABLE `databaseschema`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dbserver_id` (`dbserver_id`);

--
-- Indexes for table `datacenterdevice`
--
ALTER TABLE `datacenterdevice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rack_id` (`rack_id`),
  ADD KEY `enclosure_id` (`enclosure_id`),
  ADD KEY `powera_id` (`powera_id`),
  ADD KEY `powerB_id` (`powerB_id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `dbserver`
--
ALTER TABLE `dbserver`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deliverymodel`
--
ALTER TABLE `deliverymodel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `org_id` (`org_id`);

--
-- Indexes for table `document`
--
ALTER TABLE `document`
  ADD PRIMARY KEY (`id`),
  ADD KEY `org_id` (`org_id`),
  ADD KEY `documenttype_id` (`documenttype_id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `documentfile`
--
ALTER TABLE `documentfile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documentnote`
--
ALTER TABLE `documentnote`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documenttype`
--
ALTER TABLE `documenttype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documentweb`
--
ALTER TABLE `documentweb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enclosure`
--
ALTER TABLE `enclosure`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rack_id` (`rack_id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`),
  ADD KEY `title` (`title`(95)),
  ADD KEY `category_id` (`category_id`);
ALTER TABLE `faq` ADD FULLTEXT KEY `domains` (`domains`);

--
-- Indexes for table `faqcategory`
--
ALTER TABLE `faqcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `farm`
--
ALTER TABLE `farm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fiberchannelinterface`
--
ALTER TABLE `fiberchannelinterface`
  ADD PRIMARY KEY (`id`),
  ADD KEY `datacenterdevice_id` (`datacenterdevice_id`);

--
-- Indexes for table `functionalci`
--
ALTER TABLE `functionalci`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `org_id` (`org_id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `group`
--
ALTER TABLE `group`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `org_id` (`org_id`),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `parent_id_left` (`parent_id_left`),
  ADD KEY `parent_id_right` (`parent_id_right`);

--
-- Indexes for table `hypervisor`
--
ALTER TABLE `hypervisor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `farm_id` (`farm_id`),
  ADD KEY `server_id` (`server_id`);

--
-- Indexes for table `inline_image`
--
ALTER TABLE `inline_image`
  ADD PRIMARY KEY (`id`),
  ADD KEY `temp_id` (`temp_id`(95)),
  ADD KEY `item_class` (`item_class`(95)),
  ADD KEY `item_class_item_id` (`item_class`(95),`item_id`),
  ADD KEY `item_org_id` (`item_org_id`);

--
-- Indexes for table `iosversion`
--
ALTER TABLE `iosversion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `brand_id` (`brand_id`);

--
-- Indexes for table `ipinterface`
--
ALTER TABLE `ipinterface`
  ADD PRIMARY KEY (`id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `ipphone`
--
ALTER TABLE `ipphone`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `key_value_store`
--
ALTER TABLE `key_value_store`
  ADD PRIMARY KEY (`id`),
  ADD KEY `key_name` (`key_name`(95)),
  ADD KEY `key_name_namespace` (`key_name`(95),`namespace`(95));

--
-- Indexes for table `knownerror`
--
ALTER TABLE `knownerror`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `cust_id` (`cust_id`),
  ADD KEY `problem_id` (`problem_id`);

--
-- Indexes for table `licence`
--
ALTER TABLE `licence`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `org_id` (`org_id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `lnkapplicationsolutiontobusinessprocess`
--
ALTER TABLE `lnkapplicationsolutiontobusinessprocess`
  ADD PRIMARY KEY (`id`),
  ADD KEY `businessprocess_id` (`businessprocess_id`),
  ADD KEY `applicationsolution_id` (`applicationsolution_id`);

--
-- Indexes for table `lnkapplicationsolutiontofunctionalci`
--
ALTER TABLE `lnkapplicationsolutiontofunctionalci`
  ADD PRIMARY KEY (`id`),
  ADD KEY `applicationsolution_id` (`applicationsolution_id`),
  ADD KEY `functionalci_id` (`functionalci_id`);

--
-- Indexes for table `lnkconnectablecitonetworkdevice`
--
ALTER TABLE `lnkconnectablecitonetworkdevice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `networkdevice_id` (`networkdevice_id`),
  ADD KEY `connectableci_id` (`connectableci_id`);

--
-- Indexes for table `lnkcontacttocontract`
--
ALTER TABLE `lnkcontacttocontract`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contract_id` (`contract_id`),
  ADD KEY `contact_id` (`contact_id`);

--
-- Indexes for table `lnkcontacttofunctionalci`
--
ALTER TABLE `lnkcontacttofunctionalci`
  ADD PRIMARY KEY (`id`),
  ADD KEY `functionalci_id` (`functionalci_id`),
  ADD KEY `contact_id` (`contact_id`);

--
-- Indexes for table `lnkcontacttoservice`
--
ALTER TABLE `lnkcontacttoservice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `contact_id` (`contact_id`);

--
-- Indexes for table `lnkcontacttoticket`
--
ALTER TABLE `lnkcontacttoticket`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticket_id` (`ticket_id`),
  ADD KEY `contact_id` (`contact_id`);

--
-- Indexes for table `lnkcontracttodocument`
--
ALTER TABLE `lnkcontracttodocument`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contract_id` (`contract_id`),
  ADD KEY `document_id` (`document_id`);

--
-- Indexes for table `lnkcustomercontracttoservice`
--
ALTER TABLE `lnkcustomercontracttoservice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customercontract_id` (`customercontract_id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `sla_id` (`sla_id`);

--
-- Indexes for table `lnkdatacenterdevicetosan`
--
ALTER TABLE `lnkdatacenterdevicetosan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `san_id` (`san_id`),
  ADD KEY `datacenterdevice_id` (`datacenterdevice_id`);

--
-- Indexes for table `lnkdeliverymodeltocontact`
--
ALTER TABLE `lnkdeliverymodeltocontact`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deliverymodel_id` (`deliverymodel_id`),
  ADD KEY `contact_id` (`contact_id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `lnkdocumenttoerror`
--
ALTER TABLE `lnkdocumenttoerror`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `document_id` (`document_id`),
  ADD KEY `error_id` (`error_id`),
  ADD KEY `link_type` (`link_type`(95));

--
-- Indexes for table `lnkdocumenttofunctionalci`
--
ALTER TABLE `lnkdocumenttofunctionalci`
  ADD PRIMARY KEY (`id`),
  ADD KEY `functionalci_id` (`functionalci_id`),
  ADD KEY `document_id` (`document_id`);

--
-- Indexes for table `lnkdocumenttolicence`
--
ALTER TABLE `lnkdocumenttolicence`
  ADD PRIMARY KEY (`id`),
  ADD KEY `licence_id` (`licence_id`),
  ADD KEY `document_id` (`document_id`);

--
-- Indexes for table `lnkdocumenttopatch`
--
ALTER TABLE `lnkdocumenttopatch`
  ADD PRIMARY KEY (`id`),
  ADD KEY `patch_id` (`patch_id`),
  ADD KEY `document_id` (`document_id`);

--
-- Indexes for table `lnkdocumenttoservice`
--
ALTER TABLE `lnkdocumenttoservice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `document_id` (`document_id`);

--
-- Indexes for table `lnkdocumenttosoftware`
--
ALTER TABLE `lnkdocumenttosoftware`
  ADD PRIMARY KEY (`id`),
  ADD KEY `software_id` (`software_id`),
  ADD KEY `document_id` (`document_id`);

--
-- Indexes for table `lnkerrortofunctionalci`
--
ALTER TABLE `lnkerrortofunctionalci`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `functionalci_id` (`functionalci_id`),
  ADD KEY `error_id` (`error_id`);

--
-- Indexes for table `lnkfunctionalcitoospatch`
--
ALTER TABLE `lnkfunctionalcitoospatch`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ospatch_id` (`ospatch_id`),
  ADD KEY `functionalci_id` (`functionalci_id`);

--
-- Indexes for table `lnkfunctionalcitoprovidercontract`
--
ALTER TABLE `lnkfunctionalcitoprovidercontract`
  ADD PRIMARY KEY (`id`),
  ADD KEY `providercontract_id` (`providercontract_id`),
  ADD KEY `functionalci_id` (`functionalci_id`);

--
-- Indexes for table `lnkfunctionalcitoservice`
--
ALTER TABLE `lnkfunctionalcitoservice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `functionalci_id` (`functionalci_id`);

--
-- Indexes for table `lnkfunctionalcitoticket`
--
ALTER TABLE `lnkfunctionalcitoticket`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticket_id` (`ticket_id`),
  ADD KEY `functionalci_id` (`functionalci_id`);

--
-- Indexes for table `lnkgrouptoci`
--
ALTER TABLE `lnkgrouptoci`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `ci_id` (`ci_id`);

--
-- Indexes for table `lnkpersontoteam`
--
ALTER TABLE `lnkpersontoteam`
  ADD PRIMARY KEY (`id`),
  ADD KEY `team_id` (`team_id`),
  ADD KEY `person_id` (`person_id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `lnkphysicalinterfacetovlan`
--
ALTER TABLE `lnkphysicalinterfacetovlan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `physicalinterface_id` (`physicalinterface_id`),
  ADD KEY `vlan_id` (`vlan_id`);

--
-- Indexes for table `lnkprovidercontracttoservice`
--
ALTER TABLE `lnkprovidercontracttoservice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `providercontract_id` (`providercontract_id`);

--
-- Indexes for table `lnkservertovolume`
--
ALTER TABLE `lnkservertovolume`
  ADD PRIMARY KEY (`id`),
  ADD KEY `volume_id` (`volume_id`),
  ADD KEY `server_id` (`server_id`);

--
-- Indexes for table `lnkslatoslt`
--
ALTER TABLE `lnkslatoslt`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sla_id` (`sla_id`),
  ADD KEY `slt_id` (`slt_id`);

--
-- Indexes for table `lnksoftwareinstancetosoftwarepatch`
--
ALTER TABLE `lnksoftwareinstancetosoftwarepatch`
  ADD PRIMARY KEY (`id`),
  ADD KEY `softwarepatch_id` (`softwarepatch_id`),
  ADD KEY `softwareinstance_id` (`softwareinstance_id`);

--
-- Indexes for table `lnksubnettovlan`
--
ALTER TABLE `lnksubnettovlan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subnet_id` (`subnet_id`),
  ADD KEY `vlan_id` (`vlan_id`);

--
-- Indexes for table `lnkvirtualdevicetovolume`
--
ALTER TABLE `lnkvirtualdevicetovolume`
  ADD PRIMARY KEY (`id`),
  ADD KEY `volume_id` (`volume_id`),
  ADD KEY `virtualdevice_id` (`virtualdevice_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `org_id` (`org_id`);

--
-- Indexes for table `logicalinterface`
--
ALTER TABLE `logicalinterface`
  ADD PRIMARY KEY (`id`),
  ADD KEY `virtualmachine_id` (`virtualmachine_id`);

--
-- Indexes for table `logicalvolume`
--
ALTER TABLE `logicalvolume`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `storagesystem_id` (`storagesystem_id`);

--
-- Indexes for table `middleware`
--
ALTER TABLE `middleware`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `middlewareinstance`
--
ALTER TABLE `middlewareinstance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `middleware_id` (`middleware_id`);

--
-- Indexes for table `mobilephone`
--
ALTER TABLE `mobilephone`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model`
--
ALTER TABLE `model`
  ADD PRIMARY KEY (`id`),
  ADD KEY `brand_id` (`brand_id`);

--
-- Indexes for table `nas`
--
ALTER TABLE `nas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nasfilesystem`
--
ALTER TABLE `nasfilesystem`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `nas_id` (`nas_id`);

--
-- Indexes for table `networkdevice`
--
ALTER TABLE `networkdevice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `networkdevicetype_id` (`networkdevicetype_id`),
  ADD KEY `iosversion_id` (`iosversion_id`);

--
-- Indexes for table `networkdevicetype`
--
ALTER TABLE `networkdevicetype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `networkinterface`
--
ALTER TABLE `networkinterface`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `organization`
--
ALTER TABLE `organization`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `parent_id_left` (`parent_id_left`),
  ADD KEY `parent_id_right` (`parent_id_right`),
  ADD KEY `deliverymodel_id` (`deliverymodel_id`);

--
-- Indexes for table `osfamily`
--
ALTER TABLE `osfamily`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oslicence`
--
ALTER TABLE `oslicence`
  ADD PRIMARY KEY (`id`),
  ADD KEY `osversion_id` (`osversion_id`);

--
-- Indexes for table `ospatch`
--
ALTER TABLE `ospatch`
  ADD PRIMARY KEY (`id`),
  ADD KEY `osversion_id` (`osversion_id`);

--
-- Indexes for table `osversion`
--
ALTER TABLE `osversion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `osfamily_id` (`osfamily_id`);

--
-- Indexes for table `othersoftware`
--
ALTER TABLE `othersoftware`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patch`
--
ALTER TABLE `patch`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `pc`
--
ALTER TABLE `pc`
  ADD PRIMARY KEY (`id`),
  ADD KEY `osfamily_id` (`osfamily_id`),
  ADD KEY `osversion_id` (`osversion_id`);

--
-- Indexes for table `pcsoftware`
--
ALTER TABLE `pcsoftware`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pdu`
--
ALTER TABLE `pdu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rack_id` (`rack_id`),
  ADD KEY `powerstart_id` (`powerstart_id`);

--
-- Indexes for table `peripheral`
--
ALTER TABLE `peripheral`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`id`),
  ADD KEY `first_name` (`first_name`(95)),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `manager_id` (`manager_id`);

--
-- Indexes for table `phone`
--
ALTER TABLE `phone`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `physicaldevice`
--
ALTER TABLE `physicaldevice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `brand_id` (`brand_id`),
  ADD KEY `model_id` (`model_id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `physicalinterface`
--
ALTER TABLE `physicalinterface`
  ADD PRIMARY KEY (`id`),
  ADD KEY `connectableci_id` (`connectableci_id`);

--
-- Indexes for table `powerconnection`
--
ALTER TABLE `powerconnection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `powersource`
--
ALTER TABLE `powersource`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `printer`
--
ALTER TABLE `printer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_action`
--
ALTER TABLE `priv_action`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `realclass` (`realclass`(95));

--
-- Indexes for table `priv_action_email`
--
ALTER TABLE `priv_action_email`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_action_googlechat_notif`
--
ALTER TABLE `priv_action_googlechat_notif`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_action_itop_webhook`
--
ALTER TABLE `priv_action_itop_webhook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_action_microsoftteams_notif`
--
ALTER TABLE `priv_action_microsoftteams_notif`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_action_notification`
--
ALTER TABLE `priv_action_notification`
  ADD PRIMARY KEY (`id`),
  ADD KEY `realclass` (`realclass`(95));

--
-- Indexes for table `priv_action_rocketchat_notif`
--
ALTER TABLE `priv_action_rocketchat_notif`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_action_slack_notif`
--
ALTER TABLE `priv_action_slack_notif`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_action_webhook`
--
ALTER TABLE `priv_action_webhook`
  ADD PRIMARY KEY (`id`),
  ADD KEY `language` (`language`(95)),
  ADD KEY `remoteapplicationconnection_id` (`remoteapplicationconnection_id`),
  ADD KEY `test_remoteapplicationconnection_id` (`test_remoteapplicationconnection_id`),
  ADD KEY `realclass` (`realclass`(95));

--
-- Indexes for table `priv_app_dashboards`
--
ALTER TABLE `priv_app_dashboards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `priv_app_preferences`
--
ALTER TABLE `priv_app_preferences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `priv_async_send_email`
--
ALTER TABLE `priv_async_send_email`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_async_send_web_request`
--
ALTER TABLE `priv_async_send_web_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_async_task`
--
ALTER TABLE `priv_async_task`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created` (`created`),
  ADD KEY `event_id` (`event_id`),
  ADD KEY `realclass` (`realclass`(95));

--
-- Indexes for table `priv_auditcategory`
--
ALTER TABLE `priv_auditcategory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95));

--
-- Indexes for table `priv_auditrule`
--
ALTER TABLE `priv_auditrule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `priv_backgroundtask`
--
ALTER TABLE `priv_backgroundtask`
  ADD PRIMARY KEY (`id`),
  ADD KEY `class_name` (`class_name`(95));

--
-- Indexes for table `priv_bulk_export_result`
--
ALTER TABLE `priv_bulk_export_result`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created` (`created`);

--
-- Indexes for table `priv_change`
--
ALTER TABLE `priv_change`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date` (`date`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `origin` (`origin`);

--
-- Indexes for table `priv_changeop`
--
ALTER TABLE `priv_changeop`
  ADD PRIMARY KEY (`id`),
  ADD KEY `changeid` (`changeid`),
  ADD KEY `optype` (`optype`(95)),
  ADD KEY `objclass_objkey` (`objclass`(95),`objkey`);

--
-- Indexes for table `priv_changeop_attachment_added`
--
ALTER TABLE `priv_changeop_attachment_added`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attachment_id` (`attachment_id`);

--
-- Indexes for table `priv_changeop_attachment_removed`
--
ALTER TABLE `priv_changeop_attachment_removed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_create`
--
ALTER TABLE `priv_changeop_create`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_delete`
--
ALTER TABLE `priv_changeop_delete`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_links`
--
ALTER TABLE `priv_changeop_links`
  ADD PRIMARY KEY (`id`),
  ADD KEY `optype` (`optype`(95));

--
-- Indexes for table `priv_changeop_links_addremove`
--
ALTER TABLE `priv_changeop_links_addremove`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_links_tune`
--
ALTER TABLE `priv_changeop_links_tune`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_plugin`
--
ALTER TABLE `priv_changeop_plugin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_setatt`
--
ALTER TABLE `priv_changeop_setatt`
  ADD PRIMARY KEY (`id`),
  ADD KEY `optype` (`optype`(95));

--
-- Indexes for table `priv_changeop_setatt_custfields`
--
ALTER TABLE `priv_changeop_setatt_custfields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_setatt_data`
--
ALTER TABLE `priv_changeop_setatt_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_setatt_encrypted`
--
ALTER TABLE `priv_changeop_setatt_encrypted`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_setatt_html`
--
ALTER TABLE `priv_changeop_setatt_html`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_setatt_log`
--
ALTER TABLE `priv_changeop_setatt_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_setatt_longtext`
--
ALTER TABLE `priv_changeop_setatt_longtext`
  ADD PRIMARY KEY (`id`),
  ADD KEY `optype` (`optype`(95));

--
-- Indexes for table `priv_changeop_setatt_pwd`
--
ALTER TABLE `priv_changeop_setatt_pwd`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_setatt_scalar`
--
ALTER TABLE `priv_changeop_setatt_scalar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_setatt_tagset`
--
ALTER TABLE `priv_changeop_setatt_tagset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_setatt_text`
--
ALTER TABLE `priv_changeop_setatt_text`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_changeop_setatt_url`
--
ALTER TABLE `priv_changeop_setatt_url`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_db_properties`
--
ALTER TABLE `priv_db_properties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95));

--
-- Indexes for table `priv_event`
--
ALTER TABLE `priv_event`
  ADD PRIMARY KEY (`id`),
  ADD KEY `realclass` (`realclass`(95));

--
-- Indexes for table `priv_event_email`
--
ALTER TABLE `priv_event_email`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_event_issue`
--
ALTER TABLE `priv_event_issue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_event_loginusage`
--
ALTER TABLE `priv_event_loginusage`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `priv_event_notification`
--
ALTER TABLE `priv_event_notification`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trigger_id` (`trigger_id`),
  ADD KEY `action_id` (`action_id`),
  ADD KEY `realclass` (`realclass`(95)),
  ADD KEY `object_id` (`object_id`);

--
-- Indexes for table `priv_event_onobject`
--
ALTER TABLE `priv_event_onobject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_event_restservice`
--
ALTER TABLE `priv_event_restservice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_event_webhook`
--
ALTER TABLE `priv_event_webhook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_event_webservice`
--
ALTER TABLE `priv_event_webservice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_extension_install`
--
ALTER TABLE `priv_extension_install`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_internaluser`
--
ALTER TABLE `priv_internaluser`
  ADD PRIMARY KEY (`id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `priv_link_action_trigger`
--
ALTER TABLE `priv_link_action_trigger`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `action_id` (`action_id`),
  ADD KEY `trigger_id` (`trigger_id`);

--
-- Indexes for table `priv_module_install`
--
ALTER TABLE `priv_module_install`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `version` (`version`(95)),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `priv_oauth_client`
--
ALTER TABLE `priv_oauth_client`
  ADD PRIMARY KEY (`id`),
  ADD KEY `provider` (`provider`(95)),
  ADD KEY `name` (`name`(95)),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `priv_oauth_client_azure`
--
ALTER TABLE `priv_oauth_client_azure`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `priv_oauth_client_azure` ADD FULLTEXT KEY `scope` (`scope`);

--
-- Indexes for table `priv_oauth_client_google`
--
ALTER TABLE `priv_oauth_client_google`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `priv_oauth_client_google` ADD FULLTEXT KEY `scope` (`scope`);

--
-- Indexes for table `priv_ownership_token`
--
ALTER TABLE `priv_ownership_token`
  ADD PRIMARY KEY (`id`),
  ADD KEY `obj_class` (`obj_class`(95)),
  ADD KEY `obj_key` (`obj_key`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `priv_query`
--
ALTER TABLE `priv_query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `realclass` (`realclass`(95));

--
-- Indexes for table `priv_query_oql`
--
ALTER TABLE `priv_query_oql`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_shortcut`
--
ALTER TABLE `priv_shortcut`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `realclass` (`realclass`(95));

--
-- Indexes for table `priv_shortcut_oql`
--
ALTER TABLE `priv_shortcut_oql`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_sync_att`
--
ALTER TABLE `priv_sync_att`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sync_source_id` (`sync_source_id`),
  ADD KEY `attcode` (`attcode`(95)),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `priv_sync_att_extkey`
--
ALTER TABLE `priv_sync_att_extkey`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_sync_att_linkset`
--
ALTER TABLE `priv_sync_att_linkset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_sync_datasource`
--
ALTER TABLE `priv_sync_datasource`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `notify_contact_id` (`notify_contact_id`),
  ADD KEY `scope_class` (`scope_class`(95));

--
-- Indexes for table `priv_sync_log`
--
ALTER TABLE `priv_sync_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sync_source_id` (`sync_source_id`);

--
-- Indexes for table `priv_sync_replica`
--
ALTER TABLE `priv_sync_replica`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sync_source_id` (`sync_source_id`),
  ADD KEY `dest_class` (`dest_class`(95)),
  ADD KEY `dest_class_dest_id` (`dest_class`(95),`dest_id`);

--
-- Indexes for table `priv_tagfielddata`
--
ALTER TABLE `priv_tagfielddata`
  ADD PRIMARY KEY (`id`),
  ADD KEY `label` (`label`(95)),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `priv_trigger`
--
ALTER TABLE `priv_trigger`
  ADD PRIMARY KEY (`id`),
  ADD KEY `description` (`description`(95)),
  ADD KEY `realclass` (`realclass`(95));
ALTER TABLE `priv_trigger` ADD FULLTEXT KEY `context` (`context`);

--
-- Indexes for table `priv_trigger_onobjcreate`
--
ALTER TABLE `priv_trigger_onobjcreate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_trigger_onobjdelete`
--
ALTER TABLE `priv_trigger_onobjdelete`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_trigger_onobject`
--
ALTER TABLE `priv_trigger_onobject`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target_class` (`target_class`(95)),
  ADD KEY `realclass` (`realclass`(95));

--
-- Indexes for table `priv_trigger_onobjmention`
--
ALTER TABLE `priv_trigger_onobjmention`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_trigger_onobjupdate`
--
ALTER TABLE `priv_trigger_onobjupdate`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `priv_trigger_onobjupdate` ADD FULLTEXT KEY `target_attcodes` (`target_attcodes`);

--
-- Indexes for table `priv_trigger_onportalupdate`
--
ALTER TABLE `priv_trigger_onportalupdate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_trigger_onstatechange`
--
ALTER TABLE `priv_trigger_onstatechange`
  ADD PRIMARY KEY (`id`),
  ADD KEY `realclass` (`realclass`(95));

--
-- Indexes for table `priv_trigger_onstateenter`
--
ALTER TABLE `priv_trigger_onstateenter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_trigger_onstateleave`
--
ALTER TABLE `priv_trigger_onstateleave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priv_trigger_threshold`
--
ALTER TABLE `priv_trigger_threshold`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `priv_trigger_threshold` ADD FULLTEXT KEY `stop_watch_code` (`stop_watch_code`);

--
-- Indexes for table `priv_urp_profiles`
--
ALTER TABLE `priv_urp_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95));

--
-- Indexes for table `priv_urp_userorg`
--
ALTER TABLE `priv_urp_userorg`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `allowed_org_id` (`allowed_org_id`);

--
-- Indexes for table `priv_urp_userprofile`
--
ALTER TABLE `priv_urp_userprofile`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `profileid` (`profileid`);

--
-- Indexes for table `priv_user`
--
ALTER TABLE `priv_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contactid` (`contactid`),
  ADD KEY `login` (`login`(95)),
  ADD KEY `language` (`language`(95)),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `priv_user_local`
--
ALTER TABLE `priv_user_local`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `providercontract`
--
ALTER TABLE `providercontract`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rack`
--
ALTER TABLE `rack`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `remoteapplicationconnection`
--
ALTER TABLE `remoteapplicationconnection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `remoteapplicationtype_id` (`remoteapplicationtype_id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `remoteapplicationtype`
--
ALTER TABLE `remoteapplicationtype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `remoteitopconnection`
--
ALTER TABLE `remoteitopconnection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sanswitch`
--
ALTER TABLE `sanswitch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `server`
--
ALTER TABLE `server`
  ADD PRIMARY KEY (`id`),
  ADD KEY `osfamily_id` (`osfamily_id`),
  ADD KEY `osversion_id` (`osversion_id`),
  ADD KEY `oslicence_id` (`oslicence_id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `org_id` (`org_id`),
  ADD KEY `servicefamily_id` (`servicefamily_id`);

--
-- Indexes for table `servicefamily`
--
ALTER TABLE `servicefamily`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95));

--
-- Indexes for table `servicesubcategory`
--
ALTER TABLE `servicesubcategory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `service_id` (`service_id`);

--
-- Indexes for table `sla`
--
ALTER TABLE `sla`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `org_id` (`org_id`);

--
-- Indexes for table `slt`
--
ALTER TABLE `slt`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95));

--
-- Indexes for table `software`
--
ALTER TABLE `software`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `version` (`version`(95));

--
-- Indexes for table `softwareinstance`
--
ALTER TABLE `softwareinstance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `functionalci_id` (`functionalci_id`),
  ADD KEY `software_id` (`software_id`),
  ADD KEY `softwarelicence_id` (`softwarelicence_id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `softwarelicence`
--
ALTER TABLE `softwarelicence`
  ADD PRIMARY KEY (`id`),
  ADD KEY `software_id` (`software_id`);

--
-- Indexes for table `softwarepatch`
--
ALTER TABLE `softwarepatch`
  ADD PRIMARY KEY (`id`),
  ADD KEY `software_id` (`software_id`);

--
-- Indexes for table `storagesystem`
--
ALTER TABLE `storagesystem`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subnet`
--
ALTER TABLE `subnet`
  ADD PRIMARY KEY (`id`),
  ADD KEY `org_id` (`org_id`),
  ADD KEY `ip` (`ip`(95)),
  ADD KEY `ip_mask` (`ip_mask`(95));

--
-- Indexes for table `tablet`
--
ALTER TABLE `tablet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tape`
--
ALTER TABLE `tape`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `tapelibrary_id` (`tapelibrary_id`);

--
-- Indexes for table `tapelibrary`
--
ALTER TABLE `tapelibrary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `telephonyci`
--
ALTER TABLE `telephonyci`
  ADD PRIMARY KEY (`id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`id`),
  ADD KEY `operational_status` (`operational_status`),
  ADD KEY `ref` (`ref`(95)),
  ADD KEY `org_id` (`org_id`),
  ADD KEY `caller_id` (`caller_id`),
  ADD KEY `team_id` (`team_id`),
  ADD KEY `agent_id` (`agent_id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `ticket_incident`
--
ALTER TABLE `ticket_incident`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `servicesubcategory_id` (`servicesubcategory_id`),
  ADD KEY `parent_incident_id` (`parent_incident_id`),
  ADD KEY `parent_problem_id` (`parent_problem_id`),
  ADD KEY `parent_change_id` (`parent_change_id`);

--
-- Indexes for table `ticket_problem`
--
ALTER TABLE `ticket_problem`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `servicesubcategory_id` (`servicesubcategory_id`),
  ADD KEY `related_change_id` (`related_change_id`);

--
-- Indexes for table `ticket_request`
--
ALTER TABLE `ticket_request`
  ADD PRIMARY KEY (`id`),
  ADD KEY `approver_id` (`approver_id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `servicesubcategory_id` (`servicesubcategory_id`),
  ADD KEY `parent_request_id` (`parent_request_id`),
  ADD KEY `parent_incident_id` (`parent_incident_id`),
  ADD KEY `parent_problem_id` (`parent_problem_id`),
  ADD KEY `parent_change_id` (`parent_change_id`);

--
-- Indexes for table `typology`
--
ALTER TABLE `typology`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `virtualdevice`
--
ALTER TABLE `virtualdevice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `virtualhost`
--
ALTER TABLE `virtualhost`
  ADD PRIMARY KEY (`id`),
  ADD KEY `finalclass` (`finalclass`(95));

--
-- Indexes for table `virtualmachine`
--
ALTER TABLE `virtualmachine`
  ADD PRIMARY KEY (`id`),
  ADD KEY `virtualhost_id` (`virtualhost_id`),
  ADD KEY `osfamily_id` (`osfamily_id`),
  ADD KEY `osversion_id` (`osversion_id`),
  ADD KEY `oslicence_id` (`oslicence_id`);

--
-- Indexes for table `vlan`
--
ALTER TABLE `vlan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vlan_tag` (`vlan_tag`(95)),
  ADD KEY `org_id` (`org_id`);

--
-- Indexes for table `webapplication`
--
ALTER TABLE `webapplication`
  ADD PRIMARY KEY (`id`),
  ADD KEY `webserver_id` (`webserver_id`);

--
-- Indexes for table `webserver`
--
ALTER TABLE `webserver`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `workorder`
--
ALTER TABLE `workorder`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(95)),
  ADD KEY `ticket_id` (`ticket_id`),
  ADD KEY `team_id` (`team_id`),
  ADD KEY `owner_id` (`owner_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applicationsolution`
--
ALTER TABLE `applicationsolution`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attachment`
--
ALTER TABLE `attachment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `businessprocess`
--
ALTER TABLE `businessprocess`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `change`
--
ALTER TABLE `change`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `change_approved`
--
ALTER TABLE `change_approved`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `change_emergency`
--
ALTER TABLE `change_emergency`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `change_normal`
--
ALTER TABLE `change_normal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `change_routine`
--
ALTER TABLE `change_routine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `connectableci`
--
ALTER TABLE `connectableci`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `contacttype`
--
ALTER TABLE `contacttype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contract`
--
ALTER TABLE `contract`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contracttype`
--
ALTER TABLE `contracttype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customercontract`
--
ALTER TABLE `customercontract`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `databaseschema`
--
ALTER TABLE `databaseschema`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `datacenterdevice`
--
ALTER TABLE `datacenterdevice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dbserver`
--
ALTER TABLE `dbserver`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deliverymodel`
--
ALTER TABLE `deliverymodel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `document`
--
ALTER TABLE `document`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `documentfile`
--
ALTER TABLE `documentfile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `documentnote`
--
ALTER TABLE `documentnote`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `documenttype`
--
ALTER TABLE `documenttype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `documentweb`
--
ALTER TABLE `documentweb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `enclosure`
--
ALTER TABLE `enclosure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faqcategory`
--
ALTER TABLE `faqcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `farm`
--
ALTER TABLE `farm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fiberchannelinterface`
--
ALTER TABLE `fiberchannelinterface`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `functionalci`
--
ALTER TABLE `functionalci`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `group`
--
ALTER TABLE `group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hypervisor`
--
ALTER TABLE `hypervisor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inline_image`
--
ALTER TABLE `inline_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `iosversion`
--
ALTER TABLE `iosversion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ipinterface`
--
ALTER TABLE `ipinterface`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ipphone`
--
ALTER TABLE `ipphone`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `key_value_store`
--
ALTER TABLE `key_value_store`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `knownerror`
--
ALTER TABLE `knownerror`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `licence`
--
ALTER TABLE `licence`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkapplicationsolutiontobusinessprocess`
--
ALTER TABLE `lnkapplicationsolutiontobusinessprocess`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkapplicationsolutiontofunctionalci`
--
ALTER TABLE `lnkapplicationsolutiontofunctionalci`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkconnectablecitonetworkdevice`
--
ALTER TABLE `lnkconnectablecitonetworkdevice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkcontacttocontract`
--
ALTER TABLE `lnkcontacttocontract`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkcontacttofunctionalci`
--
ALTER TABLE `lnkcontacttofunctionalci`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkcontacttoservice`
--
ALTER TABLE `lnkcontacttoservice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkcontacttoticket`
--
ALTER TABLE `lnkcontacttoticket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkcontracttodocument`
--
ALTER TABLE `lnkcontracttodocument`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkcustomercontracttoservice`
--
ALTER TABLE `lnkcustomercontracttoservice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkdatacenterdevicetosan`
--
ALTER TABLE `lnkdatacenterdevicetosan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkdeliverymodeltocontact`
--
ALTER TABLE `lnkdeliverymodeltocontact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkdocumenttoerror`
--
ALTER TABLE `lnkdocumenttoerror`
  MODIFY `link_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkdocumenttofunctionalci`
--
ALTER TABLE `lnkdocumenttofunctionalci`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkdocumenttolicence`
--
ALTER TABLE `lnkdocumenttolicence`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkdocumenttopatch`
--
ALTER TABLE `lnkdocumenttopatch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkdocumenttoservice`
--
ALTER TABLE `lnkdocumenttoservice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkdocumenttosoftware`
--
ALTER TABLE `lnkdocumenttosoftware`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkerrortofunctionalci`
--
ALTER TABLE `lnkerrortofunctionalci`
  MODIFY `link_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkfunctionalcitoospatch`
--
ALTER TABLE `lnkfunctionalcitoospatch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkfunctionalcitoprovidercontract`
--
ALTER TABLE `lnkfunctionalcitoprovidercontract`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkfunctionalcitoservice`
--
ALTER TABLE `lnkfunctionalcitoservice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkfunctionalcitoticket`
--
ALTER TABLE `lnkfunctionalcitoticket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkgrouptoci`
--
ALTER TABLE `lnkgrouptoci`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkpersontoteam`
--
ALTER TABLE `lnkpersontoteam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkphysicalinterfacetovlan`
--
ALTER TABLE `lnkphysicalinterfacetovlan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkprovidercontracttoservice`
--
ALTER TABLE `lnkprovidercontracttoservice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkservertovolume`
--
ALTER TABLE `lnkservertovolume`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkslatoslt`
--
ALTER TABLE `lnkslatoslt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnksoftwareinstancetosoftwarepatch`
--
ALTER TABLE `lnksoftwareinstancetosoftwarepatch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnksubnettovlan`
--
ALTER TABLE `lnksubnettovlan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lnkvirtualdevicetovolume`
--
ALTER TABLE `lnkvirtualdevicetovolume`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logicalinterface`
--
ALTER TABLE `logicalinterface`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logicalvolume`
--
ALTER TABLE `logicalvolume`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `middleware`
--
ALTER TABLE `middleware`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `middlewareinstance`
--
ALTER TABLE `middlewareinstance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mobilephone`
--
ALTER TABLE `mobilephone`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `model`
--
ALTER TABLE `model`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nas`
--
ALTER TABLE `nas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nasfilesystem`
--
ALTER TABLE `nasfilesystem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `networkdevice`
--
ALTER TABLE `networkdevice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `networkdevicetype`
--
ALTER TABLE `networkdevicetype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `networkinterface`
--
ALTER TABLE `networkinterface`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `organization`
--
ALTER TABLE `organization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `osfamily`
--
ALTER TABLE `osfamily`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oslicence`
--
ALTER TABLE `oslicence`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ospatch`
--
ALTER TABLE `ospatch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `osversion`
--
ALTER TABLE `osversion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `othersoftware`
--
ALTER TABLE `othersoftware`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patch`
--
ALTER TABLE `patch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pc`
--
ALTER TABLE `pc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pcsoftware`
--
ALTER TABLE `pcsoftware`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pdu`
--
ALTER TABLE `pdu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `peripheral`
--
ALTER TABLE `peripheral`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `phone`
--
ALTER TABLE `phone`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `physicaldevice`
--
ALTER TABLE `physicaldevice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `physicalinterface`
--
ALTER TABLE `physicalinterface`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `powerconnection`
--
ALTER TABLE `powerconnection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `powersource`
--
ALTER TABLE `powersource`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `printer`
--
ALTER TABLE `printer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_action`
--
ALTER TABLE `priv_action`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `priv_action_email`
--
ALTER TABLE `priv_action_email`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `priv_action_googlechat_notif`
--
ALTER TABLE `priv_action_googlechat_notif`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_action_itop_webhook`
--
ALTER TABLE `priv_action_itop_webhook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_action_microsoftteams_notif`
--
ALTER TABLE `priv_action_microsoftteams_notif`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_action_notification`
--
ALTER TABLE `priv_action_notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `priv_action_rocketchat_notif`
--
ALTER TABLE `priv_action_rocketchat_notif`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_action_slack_notif`
--
ALTER TABLE `priv_action_slack_notif`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_action_webhook`
--
ALTER TABLE `priv_action_webhook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_app_dashboards`
--
ALTER TABLE `priv_app_dashboards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_app_preferences`
--
ALTER TABLE `priv_app_preferences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `priv_async_send_email`
--
ALTER TABLE `priv_async_send_email`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_async_send_web_request`
--
ALTER TABLE `priv_async_send_web_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_async_task`
--
ALTER TABLE `priv_async_task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_auditcategory`
--
ALTER TABLE `priv_auditcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_auditrule`
--
ALTER TABLE `priv_auditrule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_backgroundtask`
--
ALTER TABLE `priv_backgroundtask`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_bulk_export_result`
--
ALTER TABLE `priv_bulk_export_result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_change`
--
ALTER TABLE `priv_change`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `priv_changeop`
--
ALTER TABLE `priv_changeop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- AUTO_INCREMENT for table `priv_db_properties`
--
ALTER TABLE `priv_db_properties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `priv_event`
--
ALTER TABLE `priv_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `priv_event_email`
--
ALTER TABLE `priv_event_email`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_event_issue`
--
ALTER TABLE `priv_event_issue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `priv_event_loginusage`
--
ALTER TABLE `priv_event_loginusage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_event_notification`
--
ALTER TABLE `priv_event_notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_event_onobject`
--
ALTER TABLE `priv_event_onobject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_event_restservice`
--
ALTER TABLE `priv_event_restservice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_event_webhook`
--
ALTER TABLE `priv_event_webhook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_event_webservice`
--
ALTER TABLE `priv_event_webservice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_extension_install`
--
ALTER TABLE `priv_extension_install`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `priv_internaluser`
--
ALTER TABLE `priv_internaluser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `priv_link_action_trigger`
--
ALTER TABLE `priv_link_action_trigger`
  MODIFY `link_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `priv_module_install`
--
ALTER TABLE `priv_module_install`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `priv_oauth_client`
--
ALTER TABLE `priv_oauth_client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_oauth_client_azure`
--
ALTER TABLE `priv_oauth_client_azure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_oauth_client_google`
--
ALTER TABLE `priv_oauth_client_google`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_ownership_token`
--
ALTER TABLE `priv_ownership_token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_query`
--
ALTER TABLE `priv_query`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `priv_query_oql`
--
ALTER TABLE `priv_query_oql`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `priv_shortcut`
--
ALTER TABLE `priv_shortcut`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_shortcut_oql`
--
ALTER TABLE `priv_shortcut_oql`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_sync_att`
--
ALTER TABLE `priv_sync_att`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_sync_att_extkey`
--
ALTER TABLE `priv_sync_att_extkey`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_sync_att_linkset`
--
ALTER TABLE `priv_sync_att_linkset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_sync_datasource`
--
ALTER TABLE `priv_sync_datasource`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_sync_log`
--
ALTER TABLE `priv_sync_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_sync_replica`
--
ALTER TABLE `priv_sync_replica`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_tagfielddata`
--
ALTER TABLE `priv_tagfielddata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_trigger`
--
ALTER TABLE `priv_trigger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `priv_trigger_onobjcreate`
--
ALTER TABLE `priv_trigger_onobjcreate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_trigger_onobjdelete`
--
ALTER TABLE `priv_trigger_onobjdelete`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_trigger_onobject`
--
ALTER TABLE `priv_trigger_onobject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `priv_trigger_onobjmention`
--
ALTER TABLE `priv_trigger_onobjmention`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `priv_trigger_onobjupdate`
--
ALTER TABLE `priv_trigger_onobjupdate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_trigger_onportalupdate`
--
ALTER TABLE `priv_trigger_onportalupdate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_trigger_onstatechange`
--
ALTER TABLE `priv_trigger_onstatechange`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_trigger_onstateenter`
--
ALTER TABLE `priv_trigger_onstateenter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_trigger_onstateleave`
--
ALTER TABLE `priv_trigger_onstateleave`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_trigger_threshold`
--
ALTER TABLE `priv_trigger_threshold`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_urp_profiles`
--
ALTER TABLE `priv_urp_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1025;

--
-- AUTO_INCREMENT for table `priv_urp_userorg`
--
ALTER TABLE `priv_urp_userorg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `priv_urp_userprofile`
--
ALTER TABLE `priv_urp_userprofile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `priv_user`
--
ALTER TABLE `priv_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `priv_user_local`
--
ALTER TABLE `priv_user_local`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `providercontract`
--
ALTER TABLE `providercontract`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rack`
--
ALTER TABLE `rack`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `remoteapplicationconnection`
--
ALTER TABLE `remoteapplicationconnection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `remoteapplicationtype`
--
ALTER TABLE `remoteapplicationtype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `remoteitopconnection`
--
ALTER TABLE `remoteitopconnection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sanswitch`
--
ALTER TABLE `sanswitch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `server`
--
ALTER TABLE `server`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `servicefamily`
--
ALTER TABLE `servicefamily`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `servicesubcategory`
--
ALTER TABLE `servicesubcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sla`
--
ALTER TABLE `sla`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `slt`
--
ALTER TABLE `slt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `software`
--
ALTER TABLE `software`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `softwareinstance`
--
ALTER TABLE `softwareinstance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `softwarelicence`
--
ALTER TABLE `softwarelicence`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `softwarepatch`
--
ALTER TABLE `softwarepatch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `storagesystem`
--
ALTER TABLE `storagesystem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subnet`
--
ALTER TABLE `subnet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tablet`
--
ALTER TABLE `tablet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tape`
--
ALTER TABLE `tape`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tapelibrary`
--
ALTER TABLE `tapelibrary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `telephonyci`
--
ALTER TABLE `telephonyci`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `ticket_incident`
--
ALTER TABLE `ticket_incident`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `ticket_problem`
--
ALTER TABLE `ticket_problem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket_request`
--
ALTER TABLE `ticket_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `typology`
--
ALTER TABLE `typology`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `virtualdevice`
--
ALTER TABLE `virtualdevice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `virtualhost`
--
ALTER TABLE `virtualhost`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `virtualmachine`
--
ALTER TABLE `virtualmachine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vlan`
--
ALTER TABLE `vlan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `webapplication`
--
ALTER TABLE `webapplication`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `webserver`
--
ALTER TABLE `webserver`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `workorder`
--
ALTER TABLE `workorder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
