#!/bin/sh

# get ITOP_URL from .env file ignore lines starting with #
ITOP_URL=$(grep -v '^#' .env | grep ITOP_URL | cut -d '=' -f2-)

# check if ITOP_URL is empty
if [ -z "$ITOP_URL" ]
then
    echo "ITOP_URL not set"
    exit 1
fi

# concat url
URL="${ITOP_URL}utils/import-sql.php"

echo "Import sql file to itop: '${ITOP_URL}'"

curl --location --request POST "${URL}" \
--header 'Authorization: k9kNnU7BhpPAywAXnKCdAUqGhEbVN3LperUihNCWYupdtQTZKC7PHfVPfaiLDwmhefGqgCFzpch4JWZ6arfKDpjEoyyLoYcZCbny'

echo