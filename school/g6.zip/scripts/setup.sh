#!/bin/sh

# setup
if [ -d itop/dist ]; then
    rm -rf itop/dist
fi

mkdir tmp

# download itop
curl -L https://github.com/sndrnz/stuff/raw/main/school/itop-dummy.zip > tmp/itop.zip

unzip tmp/itop.zip -d tmp/itop

mv -f tmp/itop/itop-dummy/* tmp/itop

if [ -d tmp/itop/__MACOSX ]; then
    rm -rf tmp/itop/__MACOSX
fi

# copy dirs
dirs=(conf utils)

for dir in "${dirs[@]}"; do
    cp -rf itop/$dir tmp/itop
done

# modify config
ITOP_URL=$(grep -v '^#' .env | grep ITOP_URL | cut -d '=' -f2-)
DB_HOST=$(grep -v '^#' .env | grep DB_HOST | cut -d '=' -f2-)
DB_NAME=$(grep -v '^#' .env | grep DB_NAME | cut -d '=' -f2-)
DB_PASSWORD=$(grep -v '^#' .env | grep DB_PASSWORD | cut -d '=' -f2-)
DB_USER=$(grep -v '^#' .env | grep DB_USER | cut -d '=' -f2-)

src_config="./itop/conf/production/config-itop.php"
dest_config="./tmp/itop/conf/production/config-itop.php"

sed "s|<<<ITOP_URL>>>|${ITOP_URL}|g; s|<<<DB_HOST>>>|${DB_HOST}|g; s|<<<DB_NAME>>>|${DB_NAME}|g; s|<<<DB_PASSWORD>>>|${DB_PASSWORD}|g; s|<<<DB_USER>>>|${DB_USER}|g;" $src_config > $dest_config

# clean up
mv tmp/itop itop/dist
rm -rf tmp